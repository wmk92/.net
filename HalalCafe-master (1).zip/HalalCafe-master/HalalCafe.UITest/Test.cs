﻿using HalalCafe.Common;
using HalalCafe.ViewModels;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.UITest;
using Xamarin.UITest.Queries;

namespace HalalCafe.UITest
{
    [TestFixture(Platform.Android)]
   // [TestFixture(Platform.iOS)]
    public class Test
    {
        IApp app;
        Platform platform;
        public Test(Platform platform)
        {
            this.platform = platform;
        }

        [SetUp]
        public void BeforeEachTest()
        {
            app = AppInitializer.StartApp(platform);
        }

        [Test]
        [Category("Terms And Conditions Page")]
        public void Disable_Next_When_Accept_TermsOfService_Unchecked()
        {
            //Arrange
            //Act
            app.Tap("NextCommandId");

            //Assert
            app.WaitForNoElement(c => c.Marked("entryEmailId"), "should not navigate to Login page", TimeSpan.FromMilliseconds(30000));
            Assert.IsTrue(true, "should not navigate to Login page");
        }

        [Test]
        [Category("Terms And Conditions Page")]
        public void Enable_NextButton_When_Checkbox_Checked()
        {
            //Arrange
            //Act
            
            app.Tap(c => c.Marked("AcceptCheckBoxId"));

            var result = app.Query("NextCommandId")?.FirstOrDefault().Enabled;

            //Assert
            Assert.IsTrue(result != null, "Next Command should be enabled");


        }

        [Test]
        [Category("Terms And Conditions Page")]
        public void Go_Next_When_Checkbox_Checked()
        {
            //Arrange
            //Act

            app.Tap("AcceptCheckBoxId");
            app.Tap("NextCommandId");

            //Assert
            var result = app.WaitForElement(c => c.Marked("entryEmailId"), "Not navigated to Login page", TimeSpan.FromMilliseconds(30000))?.FirstOrDefault()?.ToString();
            Assert.IsTrue(result != null, "Not navigated to Login page");
        }


        [Test]
        public void Invalid_EmailId_Entered()
        {

            //Arrange
            NavtoLoginPage();
            app.EnterText("entryEmailId", "1234.com"); //invalid email pattern

            //Act
            var result = app.Query(x => x.Marked("lblEmailErrorId").Invoke("IsVisible"))?.FirstOrDefault()?.ToString();

            //Assert

            Assert.IsTrue(result != null, "Email error is not showing");
        }

        [Test]
        public void Empty_EmailId()
        {

            //Arrange
            NavtoLoginPage();
            //Act
            app.Tap("LoginSubmitId");
            var result = app.Query(x => x.Marked("lblEmailErrorId").Invoke("IsVisible"))?.FirstOrDefault()?.ToString();
            Console.Write(result);
            
            //Assert
            Assert.IsTrue(result != null, "Email error is not showing");
        }

        [Test]
        public void Empty_Password()
        {
            //Arrange
            NavtoLoginPage();
            app.EnterText("entryEmailId", "1234@gmail.com");

            //Act
            app.Tap("LoginSubmitId");
            var result = app.Query(x => x.Marked("lblPasswordErrorId").Invoke("IsVisible"))?.FirstOrDefault()?.ToString();
            Console.Write(result);

            //Assert
            Assert.IsTrue(result != null, "Password error is not showing");
        }

        [Test]
        public void Navigate_Login_Success()
        {
            //Arrange
            NavtoLoginPage();

            app.EnterText(c => c.Marked("entryEmailId"), "1234@gmail.com");
            app.EnterText(c => c.Marked("entryPasswordID"), "1234");

            //Act
            app.Tap(c => c.Marked("LoginSubmitId"));

            //Assert
            app.WaitForNoElement(c => c.Marked("entryEmailId"), "Login failed", TimeSpan.FromMilliseconds(30000));
            Assert.IsTrue(true);
        }

        public void NavtoLoginPage()
        {
            //Terms
            app.Tap("AcceptCheckBoxId");
            app.Tap("NextCommandId");

            var result = app.WaitForElement(c => c.Marked("entryEmailId"), "Not navigated to Login page", TimeSpan.FromMilliseconds(30000))?.FirstOrDefault()?.ToString();

            if (result == null)
                Assert.IsFalse(true);
        }

    }
}
