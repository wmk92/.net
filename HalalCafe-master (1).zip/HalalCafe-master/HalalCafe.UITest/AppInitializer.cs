﻿using System;
using Xamarin.UITest;
using Xamarin.UITest.Queries;

namespace HalalCafe.UITest
{
    public class AppInitializer
    {
        public static IApp StartApp(Platform platform)
        {
            if (platform == Platform.Android)
            {
                IApp app = ConfigureApp
                         .Android
                         .EnableLocalScreenshots()
                         .ApkFile(@"C:\Users\ngaddam\source\repos\HalalCafe\HalalCafe\HalalCafe.Android\bin\Release\com.GoHalal.Cafe.apk")
                         .StartApp();
                return app;
            }

            return ConfigureApp.iOS.StartApp();
        }
    }
}