﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Foundation;
using HalalCafe.Controls;
using HalalCafe.iOS.CustomEntryRenderer;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly : ExportRenderer(typeof(CustomEntry),typeof(CustomEntryRenderer))]
namespace HalalCafe.iOS.CustomEntryRenderer
{
    public class CustomEntryRenderer : EntryRenderer
    {
        protected override void OnElementPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            base.OnElementPropertyChanged(sender, e);

            if (Control == null || this.Element == null) return;

            if (e.PropertyName == CustomEntry.IsBorderErrorVisibleProperty.PropertyName)
            {
                if (((CustomEntry)this.Element).IsBorderErrorVisible)
                {
                    this.Control.Layer.BorderColor = ((CustomEntry)this.Element).BorderErrorColor.ToCGColor();
                    this.Control.Layer.BorderWidth = new nfloat(0.8);
                    this.Control.Layer.CornerRadius = 5;
                }
                else
                {
                    this.Control.Layer.BorderColor = UIColor.LightGray.CGColor;
                    this.Control.Layer.CornerRadius = 5;
                    this.Control.Layer.BorderWidth = new nfloat(0.8);
                }

            }
        }
    }
}