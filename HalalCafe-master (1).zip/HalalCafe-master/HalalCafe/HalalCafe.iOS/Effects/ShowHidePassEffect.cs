﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Foundation;
using HalalCafe.iOS.Effects;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ResolutionGroupName("Xamarin")]
[assembly: ExportEffect(typeof(ShowHidePassEffect), "ShowHidePassEffect")]
namespace HalalCafe.iOS.Effects
{
    public class ShowHidePassEffect : PlatformEffect
    {

        protected override void OnAttached()
        {
            ConfigureControl();
        }

        protected override void OnDetached()
        {

        }

        private void ConfigureControl()
        {
            if (Control != null)
            {
                UITextField vUpdatedEntry = (UITextField)Control;
                var buttonRect = UIButton.FromType(UIButtonType.Custom);
                buttonRect.SetImage(new UIImage("visibility"), UIControlState.Normal);
                buttonRect.TouchUpInside += (object sender, EventArgs e1) =>
                {
                    vUpdatedEntry.SecureTextEntry = !vUpdatedEntry.SecureTextEntry;
                    buttonRect.SetImage(new UIImage(vUpdatedEntry.SecureTextEntry ? "visibility" : "visibilityoff"), UIControlState.Normal);
                };

                buttonRect.Frame = new CoreGraphics.CGRect(0.0f, 0.0f, 24.0f, 24.0f);

                UIView paddingViewRight = new UIView(new System.Drawing.RectangleF(0.0f, 0.0f, 40.0f, 44.0f));
                paddingViewRight.Add(buttonRect);
                buttonRect.Center = paddingViewRight.Center;
                paddingViewRight.ContentMode = UIViewContentMode.BottomRight;


                vUpdatedEntry.RightView = paddingViewRight;
                vUpdatedEntry.RightViewMode = UITextFieldViewMode.Always;
            }
        }
    }
}
