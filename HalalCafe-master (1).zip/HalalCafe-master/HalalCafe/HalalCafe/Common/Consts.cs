﻿using HalalCafe.Models;
using Microsoft.AppCenter.Crashes;
using Plugin.Connectivity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HalalCafe.Common
{
    public class Consts
    {
        #region Variables
        public static string CustomerType;
        public static Transactions SelectedTransaction = null;
        public static ZXing.Result ScannedResult;
        public static readonly string EmailPattern = @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z";
        public static readonly string Currency = "RM";
        internal static readonly string CryptoKey = "Go-Halal";
        public static LoginResponseData UserDetails;       
        public static bool InternetAvailability;
        public static string SessionToken;
        public static int MerchantPayType;
        public static int MaxWalletAmount = 1000;
        public static string[] ProfilePicOptions = { App.AssemblyResourceManager.GetString("Camera"), App.AssemblyResourceManager.GetString("Gallery") };
        public static string VersionNumber = "1.8";
       
        #endregion

        #region Enums
        public enum PayType { Wallet = 0, Payment = 1 };

        #endregion

        #region API
        //
        //

        //public static readonly string BaseUrl = "http://edotservices.com.my/registrationapi/api/Authentication/";
        //public static readonly string MyPayBaseUrl = "http://stagemypay.edotservices.com.my:8080/MyWalletAPI/";

        //public static readonly string AuthenticationBaseURL = "http://104.198.233.145/registrationapi/api/Authentication/";

        //public static readonly string BaseUrl = "http://mypaystation.my/registrationapi/api/Authentication/";
        //public static readonly string MyPayBaseUrl = "http://staging.mypaystation.my/MyWalletAPI/";
       
        #region ProductionAPI
        public static readonly string ProdAuthBaseUrl = "http://ghp.mypaystation.my/registrationapi/api/Authentication/";
        public static readonly string ProdMyPayBaseUrl = "http://ghpwallet.mypaystation.my/MyWalletAPI/";
        #endregion
        public static readonly string RegistrationURL = ProdAuthBaseUrl + "registration";
        public static readonly string LoginURL = ProdAuthBaseUrl + "login";
        public static readonly string TransactionURL = ProdAuthBaseUrl + "transactiondetails";
        public static readonly string GetSessionTokenURL = ProdAuthBaseUrl + "getSessionToken";
        public static readonly string TransactionHistoryURL = ProdAuthBaseUrl + "transactionHistory/";

        public static readonly string CreateDealerURL = ProdMyPayBaseUrl + "createDealer";
        public static readonly string ChangePasswordURL = ProdMyPayBaseUrl + "changePassword";
        public static readonly string WalletBalanceURL = ProdMyPayBaseUrl + "authUser/";
        public static readonly string AddWalletBalanceURL = ProdMyPayBaseUrl + "addWalletBalance";
        public static readonly string ReduceWalletBalanceURL = ProdMyPayBaseUrl + "reduceWalletBalance";
        public static readonly string CloseSessionURL = ProdMyPayBaseUrl + "closeSession/";
        #endregion

        #region Reusable Methods
        /// <summary>
        /// checks internet is available or not
        /// </summary>
        /// <returns></returns>
        public static bool DoIHaveInternet()
        {
            if (CrossConnectivity.IsSupported)
                return CrossConnectivity.Current.IsConnected; // if connected
            else
                return false;
        }
        /// <summary>
        /// Displays Alert Message with "OK" Button across the application
        /// </summary>
        /// <param name="message"></param>
        public static async Task ShowDialog(string message, Action clickedCallback = null)
        {
            if (string.IsNullOrWhiteSpace(message))
            {
                await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
                return;
            }
            Device.BeginInvokeOnMainThread(async() => {
               await  Application.Current?.MainPage.DisplayAlert(App.AssemblyResourceManager.GetString("AlertTitle"), message,
                App.AssemblyResourceManager.GetString("Ok"));
                clickedCallback?.Invoke();

            });

        }

        /// <summary>
        /// Displays Confirm Message with "OK" and "CANCEL" Buttons across the application
        /// </summary>
        /// <param name="message"></param>
        public static async Task<bool> ShowPromtDialog(string message)
        {
            if (string.IsNullOrWhiteSpace(message))
            {
                await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
                return false;
            }

            var confirmStatus = await Application.Current.MainPage.DisplayAlert(
                App.AssemblyResourceManager.GetString("AlertTitle"), message,
                 App.AssemblyResourceManager.GetString("Yes"),
                 App.AssemblyResourceManager.GetString("No"));
            return confirmStatus;
        }


        /// <summary>
        /// Encode plain text
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string Base64Encode(String value)
        {
            if (!string.IsNullOrWhiteSpace(value))
            {
                var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(value);
                return System.Convert.ToBase64String(plainTextBytes);
            }
            ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
            return "";
        }


        /// <summary>
        /// Decode encoded value
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string Base64Decode(String value)
        {
            if (!string.IsNullOrWhiteSpace(value))
            {
                var base64EncodedBytes = System.Convert.FromBase64String(value);
                return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
            }

            ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
            return "";

        }

        public static void TrackError(Exception ex, Dictionary<string, string> keyValues)
        {
          //  #if !DEBUG
               Crashes.TrackError(ex, keyValues);
          //  #endif
        }

#endregion
    }
}
