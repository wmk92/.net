﻿using Plugin.Media.Abstractions;
using Plugin.Settings;
using Plugin.Settings.Abstractions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace HalalCafe.Common
{
    /// <summary>
    /// To store data persistently using shared preferences
    /// </summary>
    public class Settings
    {
        private static ISettings AppSettings
        {
            get
            {
                return CrossSettings.Current;
            }
        }

        #region Setting Constants

        private const string TermsAcceptedKey = "termsAccepted_key";
        private const string UsernameKey = "Username_key";
        private const string PassworddKey = "Password_key";
        private const string ProfilePicKey = "ProfilePic_key";
        private static readonly bool TermsDefault = false;
        private static readonly string UsernameDefault = string.Empty;
        private static readonly string PasswordDefault = string.Empty;
        private static readonly string ProfilePicPathDefault = "avatar.png";

        #endregion

        #region Properties
        public static bool IsTermsAccepted
        {
            get => AppSettings.GetValueOrDefault(TermsAcceptedKey, TermsDefault);
            set => AppSettings.AddOrUpdateValue(TermsAcceptedKey, value);
        }
        public static string LoginUsername
        {
            get => AppSettings.GetValueOrDefault(UsernameKey, UsernameDefault);
            set => AppSettings.AddOrUpdateValue(UsernameKey, value);
        }
        public static string LoginPassword
        {
            get => AppSettings.GetValueOrDefault(PassworddKey, PasswordDefault);
            set => AppSettings.AddOrUpdateValue(PassworddKey, value);
        }

        public static string ProfilePicPath
        {
            get => AppSettings.GetValueOrDefault(ProfilePicKey, ProfilePicPathDefault);
            set => AppSettings.AddOrUpdateValue(ProfilePicKey, value);
        }
        #endregion


    }
}
