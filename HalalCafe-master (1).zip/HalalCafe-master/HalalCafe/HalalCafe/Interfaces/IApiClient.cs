﻿using HalalCafe.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace HalalCafe.Interfaces
{

    public interface IApiClient
    {
        Task<LoginAPIWebResponse> LoginAuth(Dictionary<string, string> loginDetailsRequest);
        Task<RegisterAPIWebResponse> RegisterUser(Dictionary<string, string> userDetailsRequest,
            CreateDealerRequest createDealerRequest);
        Task<CreateDealerResponse> CreateDealer(CreateDealerRequest createDealerRequest);
        Task<bool> ChangePassword(ChangePasswordRequest changePasswordRequest);
        Task<bool> CloseSession(string sessionToken);
        Task<WalletBalanceResponse> WalletBalance(string userName, string password);
        Task<GetSessionTokenResponse> GetWalletSessionToken();
        Task<RequestWalletBalanceResponse> AddWalletBalance(AddWalletBalanceRequest addWalletBalanceRequest
            , Dictionary<string, string> transactionRequest);
        Task<RequestWalletBalanceResponse> ReduceWalletBalance(ReduceWalletBalanceRequest reduceWalletBalanceRequest, 
            Dictionary<string, string> transactionRequest);
        Task<TransactionResponse> PostTransaction(Dictionary<string, string> transactionRequest);

        Task<TransactionHistoryListResponse> GetTransactionHistory(string userId, string numberOfRecords);
       // Task ActiveRegisteredUser(string link);
    }
}
