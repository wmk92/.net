﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace HalalCafe.Interfaces
{
    public interface INavigationService
    {
        string CurrentPageKey { get; }
        void Configure(string pageKey, Type pageType);
        Task GoBack();
        Task NavigateModalAsync(string pageKey, bool animated = true);
        Task NavigateModalAsync(string pageKey, object parameter, bool animated = true);
        Task NavigateAsync(string pageKey, bool animated = true);
        Task NavigateAsync(string pageKey, object parameter, bool animated = true);
        Task SetCurrentRootPage(string page, Boolean anim);
        Task SetCurrentRootPage(string page, object parameter,Boolean anim);
        void InsertPageBefore(string pageKey);
        void GoNextRemovePrevious(string page, Boolean anim);
        void RemovePreviousPages(int noOfPages);
    }
}
