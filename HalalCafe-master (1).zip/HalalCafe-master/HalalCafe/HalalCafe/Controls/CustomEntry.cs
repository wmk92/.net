﻿using HalalCafe.Behaviors;
using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace HalalCafe.Controls
{
    public class CustomEntry : Entry
    {
        public static readonly BindableProperty IsBorderErrorVisibleProperty =
            BindableProperty.Create(nameof(IsBorderErrorVisible),typeof(bool), typeof(CustomEntry),
                false, BindingMode.TwoWay);

        public static readonly BindableProperty BorderErrorColorProperty =
            BindableProperty.Create(nameof(BorderErrorColor), typeof(Color),typeof(CustomEntry),Color.Transparent,
                BindingMode.TwoWay);

      

        public static readonly BindableProperty ErrorHintTextProperty =
        BindableProperty.Create(nameof(ErrorHintText), typeof(Object), typeof(CustomEntry), string.Empty);

  
        public bool IsBorderErrorVisible
        {
            get { return (bool) GetValue(IsBorderErrorVisibleProperty); }
            set { SetValue(IsBorderErrorVisibleProperty, value); }
        }

        public Color BorderErrorColor
        {
            get { return (Color)GetValue(BorderErrorColorProperty); }
            set { SetValue(BorderErrorColorProperty, value); }
        }

    

        public Object ErrorHintText
        {
            get { return (Object)GetValue(ErrorHintTextProperty); }
            set
            {
                SetValue(ErrorHintTextProperty, value);
            }
        }


    }
}
