﻿using HalalCafe.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HalalCafe.Controls
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class HistoryLisItem : ContentView
    {
		public HistoryLisItem ()
		{
			InitializeComponent ();
            if(Consts.CustomerType?.ToLower()?.Trim() == "customer")
            {
                lblMerchantName.IsVisible = true;
                lblReferenceNo.IsVisible = false;
            }
            else
            {
                lblReferenceNo.IsVisible = true;
                lblMerchantName.IsVisible = false;
            }
        }
	}
}