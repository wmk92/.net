﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HalalCafe.Controls
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class ConnectionStatus : ContentView
	{
		public ConnectionStatus ()
		{
			InitializeComponent ();
		}

        public void ShowMessage()
        {
            StatusMessage.IsVisible = true;
        }

        public void HideMessage()
        {
            StatusMessage.IsVisible = false;
        }
	}
}