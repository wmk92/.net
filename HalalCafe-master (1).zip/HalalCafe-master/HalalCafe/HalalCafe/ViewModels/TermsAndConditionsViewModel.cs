﻿using HalalCafe.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace HalalCafe.ViewModels
{

    /// <summary>
    /// First page of the application. User only allowed after abiding the terms and conditions
    /// </summary>
    public class TermsAndConditionsViewModel : AppBaseViewModel
    {
        #region Variables      
        private readonly string termsOfServceURL = "http://www.gohalal.com.my";
        #endregion

        #region Properties

        private bool _isAccepted = false;
        public bool IsAccepted {
            get { return _isAccepted; }
            set{
                SetProperty(ref _isAccepted, value);
                ((Command)NextCommand).ChangeCanExecute();
            }
        }

    

        #endregion

        #region Commands
        public ICommand NextCommand { set; get; }
        public ICommand NavToTermsWebCommand { private set; get; }
        #endregion

        #region Methods
        public TermsAndConditionsViewModel()
        {
            NextCommand = new Command(NextAction,()=> IsAccepted);
            NavToTermsWebCommand = new Command(NavToTermsWebAction);
        }


        /// <summary>
        /// Navigate to Login
        /// </summary>
        private void NextAction()
        {
            Settings.IsTermsAccepted = true;
            App.NavigationService.SetCurrentRootPage("LoginPage", false);
          
        }

        /// <summary>
        /// Terms of service URL open in any external browser
        /// </summary>
        private void NavToTermsWebAction()
        {
            Device.OpenUri(new Uri(termsOfServceURL));
        }

        #endregion
    }
}
