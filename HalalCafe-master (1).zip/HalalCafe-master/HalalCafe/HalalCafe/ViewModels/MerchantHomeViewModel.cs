﻿using HalalCafe.Common;
using HalalCafe.Models;
using HalalCafe.Services;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;
using ZXing;
using static HalalCafe.Common.Consts;

namespace HalalCafe.ViewModels
{
    /// <summary>
    /// Merchant home page 
    /// contains Barcode scanner and Add wallet
    /// </summary>
    public class MerchantHomeViewModel : AppBaseViewModel
    {
        #region Command
        public ICommand NavToScanCommand { get; private set; }
        #endregion

        #region Properties

        private string _walletAmount;
        public string WalletAmount
        {
            get => _walletAmount;
            set => SetProperty(ref _walletAmount, value);
        }
        public int PaymentPayType { get=>  (int)Consts.PayType.Payment; }
        public int WalletPayType { get =>  (int)Consts.PayType.Wallet;  }
        #endregion


        public MerchantHomeViewModel()
        {
            NavToScanCommand = new Command<int>(NavToScanAction);
            CallGetWalletBalanceAPI();
            //Consts.UserDetails = new LoginResponseData()
            //{
            //    first_name = "123",
            //    email = "121",
            //    usertype = "merchant",
            //    walletBalanceResponse = new WalletBalanceResponse()
            //    {
            //        businessName = "123",
            //        userId = 1,
            //        userName = "12",
            //        sessionToken = "12",
            //        walletBalance = 20.0
            //    }
            //};
        }


        /// <summary>
        /// Navigate to Scan page
        /// </summary>
        private void NavToScanAction(int scanType)
        {
            Consts.MerchantPayType = scanType;
            App.NavigationService.NavigateAsync("BarcodeScannerPage", scanType, false);
            //App.NavigationService.NavigateAsync("PaymentPage", Consts.Base64Decode("Q3VzdG9tZXIgSGFsYWwgLSBDdXN0b21lckBHb0hhbGFsLmNvbSAtIDYyMDg2Mjk0NTM0"), false);
        }

        /// <summary>
        /// Called when barcode result got from barcode scanner page
        /// </summary>
        /// <param name="scannedResult"></param>
        internal void SetBarcodeResult(Result scannedResult)
        {
            try
            {
                if (scannedResult != null)
                     App.NavigationService.NavigateAsync("PaymentPage", scannedResult.Text, false);

                    //App.NavigationService.NavigateAsync("PaymentPage", Consts.Base64Decode(scannedResult.Text), false);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Merchant Home Page BarCode Result Exception" + ex.Message);
                Consts.ShowDialog(App.AssemblyResourceManager.GetString("ScanError"));
            }
        }

       
        /// <summary>
        /// Call Customer Balance from API
        /// </summary>
        internal async void CallGetWalletBalanceAPI()
        {
            try
            {
                if (Consts.InternetAvailability)
                {
                    StartLoading();
                    WalletBalanceResponse walletBalanceResponse = await ApiClient.GetInstance().
                    WalletBalance(Consts.UserDetails.email.ToString(),
                                            Consts.UserDetails.password.ToString());
                    if (walletBalanceResponse == null ||
                        walletBalanceResponse.userId == 0)
                        await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
                    else
                    {
                        Consts.UserDetails.walletBalanceResponse = walletBalanceResponse;
                        WalletAmount =  string.Format(CultureInfo.InvariantCulture,"RM {0:0.00}", 
                            walletBalanceResponse.walletBalance);
                        UpdateMenuPanelUserInfo();
                    }
                }
            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("Merchant Wallet balance details", Consts.UserDetails?.ToString());
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("Merchant Wallet balance Exception: " + ex.Message);
                await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
            }
            finally
            {

                StopLoading();
            }

        }


    }
}
