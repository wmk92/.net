﻿using HalalCafe.Common;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace HalalCafe.ViewModels
{
    // This page scans barcode or QR code and sends the result to the previous page
    public class BarcodeScannerViewModel : AppBaseViewModel
    {
        #region Properties
        public ZXing.Result Result { get; set; }       
        public bool IsScanPagePop = true;

        /// <summary>
        ///IsScanning IsAnalyzing,Result,ScanResultCommand these are main proeprties for BarCode Scanner ZXING
        /// </summary>
        private bool _isAnalyzing = true;
        public bool IsAnalyzing
        {
            get { return this._isAnalyzing; }
            set
            {
                if (!bool.Equals(this._isAnalyzing, value))
                {
                    this._isAnalyzing = value;
                    SetProperty(ref _isAnalyzing, value);
                }
            }
        }

        private bool _isScanning = true;
        public bool IsScanning
        {
            get { return this._isScanning; }
            set
            {
                if (!bool.Equals(this._isScanning, value))
                {
                    this._isScanning = value;
                    SetProperty(ref _isScanning, value);
                }
            }
        }

        private string _pageTitle;
        public string PageTitle
        {
            get { return this._pageTitle; }
            set
            {            
                    SetProperty(ref _pageTitle, value);
            }
        }
        #endregion

        #region CommandsDeclaration
        public ICommand BackCommand { get; private set; }
        #endregion

        #region Methods
        public BarcodeScannerViewModel()
        {
            BackCommand = new Command(BackAction);
        }

        public BarcodeScannerViewModel(int scanType) : this()
        {
            PageTitle = ((Consts.PayType)scanType).ToString();
        }
        /// <summary>
        /// ScanResultCommand : Command for Scanning result from the Barcode
        /// </summary>
        public Command QRScanResultCommand
        {
            get
            {
                return new Command(async() =>
                {
                    try
                    {
                        IsAnalyzing = false;
                        IsScanning = false;

                        Device.BeginInvokeOnMainThread(() =>
                        {
                            if (IsScanPagePop && Result != null)
                            {
                                Consts.ScannedResult = Result;//Captured result will be assign to this ScannerResult (Zxing Scanner Result)
                                App.NavigationService.GoBack();//Navigate to prevoius page from the Scanner
                                IsScanPagePop = false;
                            }

                        });
                    }
                    catch (Exception ex)
                    {
                        Dictionary<string, string> keyValues = new Dictionary<string, string>();
                        keyValues.Add("ScannerResult", Result?.ToString());
                        Consts.TrackError(ex, keyValues);
                        Debug.WriteLine("Scanner page OpenBarCode exception " + ex.Message);
                        await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
                    }


                });
            }
        }
        /// <summary>
        /// Android
        /// Hardware Back and Header Back
        /// </summary>
        internal void BackAction()
        {
            App.NavigationService.GoBack();
        }
        #endregion

    }
}
