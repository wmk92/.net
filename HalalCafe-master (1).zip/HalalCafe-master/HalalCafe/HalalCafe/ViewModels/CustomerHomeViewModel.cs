﻿using HalalCafe.Common;
using HalalCafe.Models;
using HalalCafe.Services;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;
using ZXing;

//Customer Home Page appears after Customer login
namespace HalalCafe.ViewModels
{
    /// <summary>
    /// Landing page
    /// </summary>
    public class CustomerHomeViewModel : AppBaseViewModel
    {
        #region Command
        public ICommand NavToQRPageCommand { private set; get; }
        #endregion

        #region Properties
        private string _userName; //TODO replicated in master page
        public string UserName
        {
            get => _userName;
            set => SetProperty(ref _userName, value);
        }

        private string _walletAmount;
        public string WalletAmount
        {
            get => _walletAmount;
            set => SetProperty(ref _walletAmount, value);
        }


        #endregion

        #region Methods
        public CustomerHomeViewModel()
        {
            NavToQRPageCommand = new Command(NavToQRPageAction);
            CallGetWalletBalanceAPI();
            //Consts.UserDetails = new LoginResponseData()
            //{
            //    first_name = "123",
            //    email = "121",
            //    usertype = "merchant",
            //    walletBalanceResponse = new WalletBalanceResponse()
            //    {
            //        businessName = "123",
            //        userId = 1,
            //        userName = "12",
            //        sessionToken = "12",
            //        walletBalance = 20.0
            //    }
            //};


        }

        /// <summary>
        /// Call Customer Balance from API
        /// </summary>
        internal async void CallGetWalletBalanceAPI()
        {
            try
            {               
                if (Consts.InternetAvailability)
                {
                    StartLoading();
                    WalletBalanceResponse walletBalanceResponse = await ApiClient.GetInstance().
                    WalletBalance(Consts.UserDetails.email.ToString(),
                                            Consts.UserDetails.password.ToString());
                    if (walletBalanceResponse == null ||
                        walletBalanceResponse.userId == 0)
                        await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
                    else
                    {
                        Consts.UserDetails.walletBalanceResponse = walletBalanceResponse;
                        UserName = walletBalanceResponse.businessName;
                        WalletAmount = string.Format(CultureInfo.InvariantCulture, "RM {0:0.00}",
                            walletBalanceResponse.walletBalance.
                            ToString(CultureInfo.InvariantCulture));
                        UpdateMenuPanelUserInfo();
                    }
                }
            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("Wallet balance details", Consts.UserDetails?.ToString());
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("Wallet balance Exception: " + ex.Message);
                await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
            }
            finally
            {

                StopLoading();
            }

        }      

        internal async void NavToQRPageAction()
        {
            await App.NavigationService.NavigateAsync("CustomerQRPage", false);
        }

     
        #endregion
    }
}
