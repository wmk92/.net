﻿using HalalCafe.Common;
using HalalCafe.Models;
using HalalCafe.Views;
using MvvmHelpers;
using Plugin.Media;
using Plugin.Media.Abstractions;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HalalCafe.ViewModels
{
    /// <summary>
    /// Master page View model. It has listview bind and selection
    /// </summary>
    public class MainMasterDetailMasterViewModel  : BaseViewModel
    {
        #region Properties
        public ObservableCollection<MainMasterDetailPageMenuItem> MenuItems { get; set; }
        private bool _isCustomer = false;
        public bool IsCustomer { get => _isCustomer; set => SetProperty(ref _isCustomer, value); }

        private string _userName;
        public string UserName { get => _userName; set => SetProperty(ref _userName, value); }

        private string _userEmailId;
        public string UserEmailId { get => _userEmailId; set => SetProperty(ref _userEmailId, value); }

        private ImageSource _profilePic = Settings.ProfilePicPath;
        public ImageSource ProfilePic { get => _profilePic; set => SetProperty(ref _profilePic, value); }

        public string VersionNumber { get => Consts.VersionNumber; }

        private MainMasterDetailPageMaster _mainMasterDetailPageMaster;
        /// <summary>
        /// Listview selected Bindable property
        /// </summary>
        private MainMasterDetailPageMenuItem _masterMenuItemSelected;
        public MainMasterDetailPageMenuItem MasterMenuItemSelected
        {
            get => _masterMenuItemSelected;
            set
            {
                SetProperty(ref _masterMenuItemSelected, value);
                if (value != null)
                    NavToMenuItemSelected();
            }
        }



        #endregion

        #region Commands
        public ICommand ProfilePicCommand => new Command(async() => await ProfilePicAction());

      
        #endregion


        #region Method  

        /// <summary>
        /// Master details Master constructor
        /// </summary>
        public MainMasterDetailMasterViewModel(MainMasterDetailPageMaster mainMasterDetailPageMaster)
        {
            this._mainMasterDetailPageMaster = mainMasterDetailPageMaster;

            //Add data to the listview
            MenuItems = new ObservableCollection<MainMasterDetailPageMenuItem>();
            if (Consts.CustomerType?.ToLower()?.Trim() == "customer") //customer
            {
                IsCustomer = true; //if customer show balance in master panel
                MenuItems.Add(new MainMasterDetailPageMenuItem { Id = 0, Title = "Home", Icon = "home.png", TargetType = typeof(CustomerHomePage) });
            }
            else //Merchant
                MenuItems.Add(new MainMasterDetailPageMenuItem { Id = 0, Title = "Home", Icon = "home.png", TargetType = typeof(MerchantHomePage) });
            MenuItems.Add(new MainMasterDetailPageMenuItem { Id = 1, Title = "Transactions", Icon = "transactions.png", TargetType = typeof(HistoryPage) });
            MenuItems.Add(new MainMasterDetailPageMenuItem { Id = 2, Title = "Logout", Icon = "logout.png", TargetType = typeof(LoginPage) });

            UpdateUserInfo();
        }


        /// <summary>
        /// Opens camera and bind capatured image
        /// </summary>
        private async Task ProfilePicAction()
        {
            var action = await Application.Current?.MainPage.DisplayActionSheet(App.AssemblyResourceManager.GetString("Select"),
                App.AssemblyResourceManager.GetString("Cancel"),null, Consts.ProfilePicOptions);

            if (action == Consts.ProfilePicOptions[0]) //Camera
                await TakePicture();
            else if (action == Consts.ProfilePicOptions[1]) //Gallery
                TakeFromGallery();
            
        }


        /// <summary>
        /// Take picture from camera
        /// </summary>
        /// <returns></returns>
        private async Task TakePicture()
        {
            try
            {
                
                await CrossMedia.Current.Initialize();

                if (!CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakePhotoSupported)
                {
                    await Consts.ShowDialog(App.AssemblyResourceManager.GetString("CameraNA"));
                    return;
                }

                var file = await CrossMedia.Current.TakePhotoAsync(new Plugin.Media.Abstractions.StoreCameraMediaOptions
                {
                    Directory = "HalalCafe",
                    Name = "profilePic.jpg",
                    SaveToAlbum = true,
                    PhotoSize = PhotoSize.Medium,
                    SaveMetaData = false

                });

                if (file == null)
                    return;

                await Consts.ShowDialog("File Location" + file.Path);
                Settings.ProfilePicPath = file.Path;
                ProfilePic = ImageSource.FromStream(() =>
                {
                    var stream = file.GetStream();
                    return stream;
                });

            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("TakingPicFromCamera", CrossMedia.Current.IsTakePhotoSupported.ToString());
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("TakePicFromCamera Exception: " + ex.Message);
                await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
            }
        }


        //Pick picture from Gallery
        private async void TakeFromGallery()
        {
            try
            {
                if (!CrossMedia.Current.IsPickPhotoSupported)
                {
                    await Consts.ShowDialog(App.AssemblyResourceManager.GetString("GalleryAccessFailed"));
                    return;
                }
                var file = await CrossMedia.Current.PickPhotoAsync(new Plugin.Media.Abstractions.PickMediaOptions
                {
                    PhotoSize = PhotoSize.Medium,
                    SaveMetaData  = false
                });
                if (file == null)
                    return;

                await Consts.ShowDialog("File Location" + file.Path);
                Settings.ProfilePicPath = file.Path;
                ProfilePic = ImageSource.FromStream(() =>
                {
                    var stream = file.GetStream();
                    return stream;
                });
            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("TakeFromGallery", CrossMedia.Current.IsPickPhotoSupported.ToString());
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("TakeFromGallery Exception: " + ex.Message);
                await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
            }
        }
       
        /// <summary>
        /// Master listview item selected action
        /// </summary>
        /// <param name="masterPageMenuItem"></param>
        private async void NavToMenuItemSelected()
        {
            try
            {
                var mainPage = ((Application.Current.MainPage as NavigationPage).CurrentPage as MasterDetailPage);
                if (mainPage != null)
                {
                    if (_masterMenuItemSelected.Title == "Logout")
                        await App.NavigationService.SetCurrentRootPage("LoginPage",false);
                    else
                        await NavToMenu(mainPage, _masterMenuItemSelected.TargetType);
                }
                MasterMenuItemSelected = null;
            }
            catch (NullReferenceException nre)
            {
               await Consts.ShowDialog(nre.Message);
            }
            catch (Exception ex)
            {
                await Consts.ShowDialog(ex.Message);
            }
        }


        /// <summary>
        /// Update User info in the menu panel with the API data
        /// </summary>
        public void UpdateUserInfo()
        {
            WalletBalanceResponse walletBalanceResponse = Consts.UserDetails?.walletBalanceResponse;
            if (walletBalanceResponse != null)
            {
                UserName = walletBalanceResponse?.businessName;
                UserEmailId = walletBalanceResponse?.userName;
                _mainMasterDetailPageMaster.AddWalletAmountLevel(walletBalanceResponse.walletBalance);
               
            }
        }

        /// <summary>
        /// Nav to selected menu item
        /// </summary>
        /// <param name="mainPage"></param>
        /// <param name="target"></param>
        private async Task NavToMenu(MasterDetailPage mainPage, Type target)
        {
            try {
                mainPage.IsPresented = false;  // left menu drawer
                var page = (Page)Activator.CreateInstance(target);
                mainPage.Detail = new NavigationPage(page); //Detail page
            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("Menu target", target?.ToString());
                Consts.TrackError(ex, keyValues);
                await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
            }
        }
        #endregion
    }
}
