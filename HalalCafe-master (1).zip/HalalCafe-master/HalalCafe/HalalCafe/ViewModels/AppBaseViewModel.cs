﻿using HalalCafe.Common;
using MvvmHelpers;
using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace HalalCafe.ViewModels
{
    /// <summary>
    /// This is BaseViewModel, which is for sharing common data, MVVM features across the application
    /// </summary>
    public class AppBaseViewModel : BaseViewModel
    {
        #region Properties

        private bool isPageShowing = false;
        public bool IsPageShowing
        {
            get { return isPageShowing; }
            set
            {
                SetProperty(ref isPageShowing, value);
            }
        }        

        private bool _showInternetStatus;
        public bool ShowInternetStatus
        {
            get { return _showInternetStatus; }
            set
            {
                SetProperty(ref _showInternetStatus, value);
            }
        }


        #endregion

        #region Methods
        //Constructor
        public AppBaseViewModel()
        {
            CheckInternetAvailability();
        }

        public void CheckInternetAvailability()
        {
            Consts.InternetAvailability = Consts.DoIHaveInternet();
            ShowInternetStatus = Consts.InternetAvailability;
        }

        /// <summary>
        /// UPdate menu panel user info and wallet balance
        /// </summary>
        internal void UpdateMenuPanelUserInfo()
        {
            var mainPage = ((Application.Current.MainPage as NavigationPage).CurrentPage as MasterDetailPage);
            if (mainPage != null)
            {
                ((mainPage.Master).BindingContext as MainMasterDetailMasterViewModel).UpdateUserInfo();
            }
        }

        /// <summary>
        ///Displays Activity Indicator
        /// </summary>
        public void StartLoading()
        {
            IsBusy = true; //Xamarin forms property
            IsPageShowing = false; //Hides the page
        }

        /// <summary>
        /// Hides Activity Indicator
        /// </summary>
        public void StopLoading()
        {
            IsBusy = false;//Xamarin forms property
            IsPageShowing = true; //Shows the page
        }
        #endregion
    }
}
