﻿using HalalCafe.Common;
using HalalCafe.Models;
using HalalCafe.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HalalCafe.ViewModels
{
    /// <summary>
    /// Constains history of last scanned transactions
    /// </summary>
    public class HistoryViewModel : AppBaseViewModel
    {
        #region Properties
        private bool isDataExists;

        public bool IsDataExists
        {
            get { return isDataExists; }
            set { SetProperty(ref isDataExists, value); }
        }

        private bool isDataEmpty;

        public bool IsDataEmpty
        {

            get { return isDataEmpty; }

            set { SetProperty(ref isDataEmpty, value); }
        }

        private ObservableCollection<TransactionHistory> historyObservList = new ObservableCollection<TransactionHistory>();
        public ObservableCollection<TransactionHistory> HistoryObservList
        {

            get {return historyObservList; }

            set {
                SetProperty(ref historyObservList, value);
                IsDataExists = value.Count > 0;
                IsDataEmpty = !IsDataExists;
            }
        }


        private string selectedTransactions;
        public string SelectedTransactions
        {
            get { return selectedTransactions; }
            set { SetProperty(ref selectedTransactions, value); }
        }

        #endregion

        #region Commands
        public ICommand FilterCommand { get; private set; }
        #endregion


        #region Methods
        public HistoryViewModel()
        {
            FilterCommand = new Command(FilterAction);
        }


        /// <summary>
        /// Get Transaction history of loggedin user
        /// </summary>
      
        public async Task HistoryTransactionsAPICall()
        {
            TransactionHistoryListResponse transactionHistoryListResponse = null;
            try
            {
                StartLoading();
                if (Consts.InternetAvailability)
                {
                    HistoryObservList.Clear();
                    transactionHistoryListResponse = await ApiClient.GetInstance().
                    GetTransactionHistory(Consts.UserDetails.email, SelectedTransactions);
                    if (transactionHistoryListResponse == null ||
                        transactionHistoryListResponse.status == false) //ERROR
                        await Consts.ShowDialog(transactionHistoryListResponse.message);
                    else
                    {
                        HistoryObservList = new ObservableCollection<TransactionHistory>
                            (transactionHistoryListResponse.TransactionHistoryList
                           // .Select(x => (x.transactiondate = "0000-00-00")).ToList()
                            .OrderByDescending(x => DateTime.ParseExact(x.transactiondate.Trim(), "yyyy-MM-dd", CultureInfo.InvariantCulture)).ToList());
                    }
                }
            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("History Transaction details", transactionHistoryListResponse?.ToString());
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("History Transaction Exception: " + ex.Message);
                await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
            }
            finally
            {
                StopLoading();
            }          
           
        }


        /// <summary>
        /// Load Static History data into listview
        /// </summary>
        private  void FilterAction()
        {
            App.NavigationService.NavigateAsync("DateFilter", false);
        }

        internal void BackAction()
        {
            App.NavigationService.SetCurrentRootPage("MainMasterDetailPage", false);
        }

        public async void setSelectedTransactions()
        {
            if (Consts.SelectedTransaction != null)
                SelectedTransactions = Consts.SelectedTransaction.TransactionNumber;
            else
                SelectedTransactions = "10";

            await HistoryTransactionsAPICall();
        }

        #endregion

    }


}
