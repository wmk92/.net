﻿using HalalCafe.Common;
using HalalCafe.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Transactions;
using System.Windows.Input;
using Xamarin.Forms;

namespace HalalCafe.ViewModels
{
    class FilterViewModel : AppBaseViewModel
    {


        private bool isDataExists;

        public bool IsDataExists
        {
            get { return isDataExists; }
            set { SetProperty(ref isDataExists, value); }
        }

        private bool isDataEmpty;

        public bool IsDataEmpty
        {
             get { return isDataEmpty; }

            set { SetProperty(ref isDataEmpty, value); }
        }

        private Transactions selectedTransaction;

        public Transactions SelectedTransaction
        {
            get { return selectedTransaction; }
            set {

                SetProperty(ref selectedTransaction, value);
                if (value != null)
                {                    
                    resetSelections();
                    if (selectedTransaction != null)
                            SelectedTransaction.IsSelected = true;
                }

            }
        }

        private void resetSelections()
        {

            foreach(var item in TransactionList)
            {
                if (item.IsSelected)
                    item.IsSelected = false;
            }
           
        }

        private ObservableCollection<Transactions> transactionList;


        public ObservableCollection<Transactions> TransactionList
        {

            get { return transactionList; }

            set
            {
                SetProperty(ref transactionList, value);
                IsDataExists = value.Count > 0;
                IsDataEmpty = !IsDataExists;
            }
        }

        

       public ICommand ContinueCommand { get; private set; }


        public FilterViewModel()
        {


            ContinueCommand = new Command(ContinueAction);

            setTransactions();



        }

        private void ContinueAction()
        {
            
            Consts.SelectedTransaction = SelectedTransaction;
            App.NavigationService.GoBack();

        }

        private void setTransactions()
        {
            List<Transactions> transactionList = new List<Transactions>();
            transactionList.Add(new Transactions { TransactionNumber = "10", IsSelected = false });
            transactionList.Add(new Transactions { TransactionNumber = "20" , IsSelected = false});
            transactionList.Add(new Transactions { TransactionNumber = "30" , IsSelected = false});
            TransactionList = new ObservableCollection<Transactions>(transactionList);
            if (Consts.SelectedTransaction != null)
                SelectedTransaction = TransactionList.First<Transactions>(x=>x.TransactionNumber == Consts.SelectedTransaction.TransactionNumber);
            else
                SelectedTransaction = TransactionList[0];
        }

        private void updateTransactions(string previousSelected)
        {
            
            foreach(var item in TransactionList)
            {
                if(previousSelected.Equals(item.TransactionNumber))
                    item.IsSelected = true;
            }


        }
    }
}
