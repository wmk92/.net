﻿using HalalCafe.Common;
using HalalCafe.Models;
using HalalCafe.Services;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Input;
using Xamarin.Forms;

namespace HalalCafe.ViewModels
{
    /// <summary>
    /// User registration
    /// </summary>
    class SignupViewModel : UserSwitchViewModel
    {

        #region Properties
       

        private SignUpEntry _signUpView;
        public SignUpEntry SignUpView
        {
            get => _signUpView;
            set => SetProperty(ref _signUpView, value);
        }


        private string _firstName;
        public string FirstName
        {
            get => _firstName;
            set => SetProperty(ref _firstName, value);
        }

        private string _lastName;

        public string LastName
        {
            get => _lastName;
            set => SetProperty(ref _lastName, value);
        }

        private string _email;

        public string Email
        {
            get => _email;
            set => SetProperty(ref _email, value);
        }

        private string _password;
        public string Password
        {
            get => _password;
            set => SetProperty(ref _password, value);
        }

        private string _mobile;
        public string Mobile
        {
            get => _mobile;
            set => SetProperty(ref _mobile, value);
        }



        private string address1;
        public string Address1{ get => address1;  set => SetProperty(ref address1 , value); }

        private string address2;
        public string Address2 { get => address2; set => SetProperty(ref address2, value); }

        private string state;
        public string State { get => state; set => SetProperty(ref state, value); }

        private string city;
        public string City { get => city; set => SetProperty(ref city, value); }

        private string country;
        public string Country { get => country; set => SetProperty(ref country, value); }


        #endregion

        #region Read only Variables
        public readonly string TenantName = "My Pay";
        public readonly string DistributorName = "mypay md 2";
        #endregion

        #region Commands
        public ICommand SignupCommand { get; private set; }
        #endregion

        #region Methods
        public SignupViewModel()
        {
            SignUpView = new SignUpEntry();            
            SignupCommand = new Command(SignupAction);
        }


        /// <summary>
        /// Register submit
        /// </summary>
        private void SignupAction()
        {
                if (string.IsNullOrWhiteSpace(SignUpView.FirstName.Name?.Trim()))
                    SignUpView.FirstName.IsNotValid = true;                  
                else if (string.IsNullOrWhiteSpace(SignUpView.LastName.Name?.Trim()))
                    SignUpView.LastName.IsNotValid = true;
                
                else if (string.IsNullOrWhiteSpace(SignUpView.Email.Name?.Trim())
                    || !Regex.IsMatch(SignUpView.Email.Name?.Trim(), Consts.EmailPattern))
                    SignUpView.Email.IsNotValid = true;

                else if (string.IsNullOrWhiteSpace(SignUpView.Password.Name?.Trim()))
                    SignUpView.Password.IsNotValid = true;                            

                else if (Consts.InternetAvailability)
                     CallRegisterAPI();
        }

        private async void CallRegisterAPI()
        {
            Dictionary<string, string> userDetails = null;
            CreateDealerRequest createDealerRequest = null;
            try
            {
                StartLoading();
                userDetails = new Dictionary<string, string>
                {
                        { "first_name", SignUpView.FirstName.Name?.Trim()},
                        { "last_name", SignUpView.LastName.Name?.Trim()},
                        { "email", SignUpView.Email.Name?.Trim() },
                        { "password",SignUpView.Password.Name?.Trim()},
                        { "phone",SignUpView.Mobile.Name?.Trim()},
                        { "address1", Address1?.Trim()},
                        { "address2", Address2?.Trim()},
                        { "state", State?.Trim()},
                        { "country",Country?.Trim()},
                        { "city",City?.Trim() },
                        { "usertype", "Customer"}
                };

                createDealerRequest = new CreateDealerRequest()
                {
                    tenant = TenantName,
                    distributorName = DistributorName,
                    subdistributorName = string.Empty,
                    dealerName = SignUpView.FirstName.Name?.Trim(),
                    contactName  = SignUpView.LastName.Name?.Trim(),
                    contactEmail = SignUpView.Email.Name?.Trim(),
                    contactPhone = SignUpView.Mobile.Name?.Trim(),
                    userName = SignUpView.Email.Name?.Trim()
                };

                RegisterAPIWebResponse userRegisterResponse = await ApiClient.GetInstance().
                    RegisterUser(userDetails, createDealerRequest);

                //Validate API response
                if (userRegisterResponse == null || !userRegisterResponse.status)
                    await Consts.ShowDialog(userRegisterResponse.message);
                else
                {
                    // await ApiClient.GetInstance().ActiveRegisteredUser(userRegisterResponse.email_link);
                        await Consts.ShowDialog(App.AssemblyResourceManager.
                        GetString("RegisterSuccessful"),async()=>{

                            await App.NavigationService.NavigateAsync("LoginPage", false);

                        });
                   
                }
            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("User Register Action userDetails", userDetails?.ToString());
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("User Register Exception: " + ex.Message);
                await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
            }
            finally { StopLoading(); }
            
        }
        #endregion
    }
}
