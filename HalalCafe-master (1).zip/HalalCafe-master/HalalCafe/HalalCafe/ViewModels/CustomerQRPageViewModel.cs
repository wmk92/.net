﻿using HalalCafe.Common;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace HalalCafe.ViewModels
{
    public class CustomerQRPageViewModel : AppBaseViewModel
    {
        #region Command
        #endregion

        #region Properties

        private string _userName; //TODO replicated in master page
        public string UserName
        {
            get => _userName;
            set => SetProperty(ref _userName, value);
        }

        private string _userEmailId;
        public string UserEmailId
        {
            get => _userEmailId;
            set => SetProperty(ref _userEmailId, value);
        }

        private string _walletAmount =
             string.Format(CultureInfo.InvariantCulture, "RM {0:0.00}",
                            Consts.UserDetails.walletBalanceResponse.walletBalance.
                            ToString(CultureInfo.InvariantCulture));
        public string WalletAmount
        {
            get => _walletAmount;
            set => SetProperty(ref _walletAmount, value);
        }

        private string _customerInfo = CreateQrcode();

        //Consts.Base64Encode(
        //    $"{Consts.UserDetails.first_name} ~ " +
        //    $"{Consts.UserDetails.email} ~ " +
        //    $"{Consts.UserDetails.walletBalanceResponse.userId} ~" +
        //    $"{Consts.UserDetails.walletBalanceResponse.walletBalance}"); //Name ~ Email Id ~ user id ~ wallet amount

        public string CustomerInfo
        {
            get => _customerInfo;
            set => SetProperty(ref _customerInfo, value);
        }
        #endregion

        #region Methods
        public CustomerQRPageViewModel()
        {
            UserName = Consts.UserDetails?.walletBalanceResponse.businessName;
            UserEmailId = Consts.UserDetails?.walletBalanceResponse.userName;
        }

        private static string CreateQrcode()
        {
            JObject qrjObj = new JObject();
            qrjObj.Add("firstname", Crypto.Encrypt(Consts.UserDetails.first_name, Consts.CryptoKey));
            qrjObj.Add("email", Crypto.Encrypt(Consts.UserDetails.email, Consts.CryptoKey));
            qrjObj.Add("userId", Crypto.Encrypt(Consts.UserDetails.walletBalanceResponse.userId.ToString(), Consts.CryptoKey));
            qrjObj.Add("walletBalance", Crypto.Encrypt(Consts.UserDetails.walletBalanceResponse.walletBalance.ToString(), Consts.CryptoKey));

            return qrjObj.ToString();
        }
        #endregion
    }
}
