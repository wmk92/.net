﻿using HalalCafe.Common;
using HalalCafe.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace HalalCafe.ViewModels
{
    public class TransactionDetailsViewModel : AppBaseViewModel
    {


        #region Properties

        private double _amountPaid;
        public double AmountPaid
        {
            get { return _amountPaid; }
            set { SetProperty(ref _amountPaid , value); }
        }

        private string _accountName;
        public string AccountName
        {
            get { return _accountName; }
            set { SetProperty(ref _accountName, value); }
        }

        private string _referenceNumber;
        public string ReferenceNumber
        {
            get { return _referenceNumber; }
            set { SetProperty(ref _referenceNumber,value); }
        }

        private string _transactionDate;
        public string TransactionDate
        {
            get { return _transactionDate; }
            set { SetProperty(ref _transactionDate, value); }
        }

        private string _tranactionSuccess;
        public string TranactionSuccess
        {
            get { return _tranactionSuccess; }
            set { SetProperty(ref _tranactionSuccess, value); }
        }

        private bool _isPayment;
        public bool IsPayment
        {
            get { return _isPayment; }
            set { SetProperty(ref _isPayment, value); }
        }

        #endregion
        #region Commands

        public ICommand NavToHome { private set; get; }
        #endregion

        #region Methods
        public TransactionDetailsViewModel()
        {
            NavToHome = new Command(NavToHomeAction);
        }

        public TransactionDetailsViewModel(PaymentInformation paymentInformation) : this()
        {
            if (paymentInformation == null)
                  Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
            else
            {
                if(Consts.MerchantPayType == (int)Consts.PayType.Wallet)
                {
                    TranactionSuccess = App.AssemblyResourceManager.GetString("SuccessRecharge");
                    IsPayment = false;
                }
                else
                {
                    TranactionSuccess = App.AssemblyResourceManager.GetString("SuccessPayment");
                    IsPayment = true;
                }
                AccountName = paymentInformation.CustomerName;                
                ReferenceNumber = paymentInformation.SessionToken.Substring(7); //show till the end
                AmountPaid =  paymentInformation.TotalAmount;
                TransactionDate = paymentInformation.TransactionDate;
            }
        }

        private void NavToHomeAction()
        {
            App.NavigationService.SetCurrentRootPage("MainMasterDetailPage",false);
        }

        #endregion
    }
}
