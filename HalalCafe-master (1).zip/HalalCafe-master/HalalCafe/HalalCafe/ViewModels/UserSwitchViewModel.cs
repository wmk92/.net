﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace HalalCafe.ViewModels
{
    /// <summary>
    /// Switch base class to handle switch events
    /// </summary>
    public class UserSwitchViewModel : AppBaseViewModel
    {
        #region Commands
        public ICommand CustomerCommand { get; private set; }

        public ICommand MerchantCommand
        {
            get;
            private set;
        }
        #endregion

        #region Properties
        public static readonly string FocusedColor = "#bf2733";
        public static readonly string FocusedTextColor = "#ffffff";
        public static readonly string UnfocusedColor = "#b9b9b9";
        public static readonly string UnfocusedTextColor = "#ffffff";

        private string _customerSelectedBackground = UserSwitchViewModel.UnfocusedColor;
        public string CustomerSelectedBackground
        {
            get { return _customerSelectedBackground; }
            set
            {
                SetProperty(ref _customerSelectedBackground, value);

            }

        }

        private string _customerSelectedTextColor = UserSwitchViewModel.UnfocusedTextColor;
        public string CustomerSelectedTextColor
        {
            get { return _customerSelectedTextColor; }
            set
            {
                SetProperty(ref _customerSelectedTextColor, value);

            }

        }


        private string _merchantSelectedBackground = UserSwitchViewModel.UnfocusedColor;
        public string MerchantSelectedBackground
        {
            get { return _merchantSelectedBackground; }
            set
            {
                SetProperty(ref _merchantSelectedBackground, value);

            }
        }

        private string _merchantSelectedTextColor = UserSwitchViewModel.UnfocusedTextColor;
        public string MerchantSelectedTextColor
        {
            get { return _merchantSelectedTextColor; }
            set
            {
                SetProperty(ref _merchantSelectedTextColor, value);

            }

        }

        #endregion



        #region Methods

        public UserSwitchViewModel()
        {
            MerchantCommand = new Command(MerchantAction);
            CustomerCommand = new Command(CustomerAction);
        }
        /// <summary>
        /// Merchant switch clicked
        /// </summary>
        private void MerchantAction()
        {
            MerchantSelectedBackground = FocusedColor;
            MerchantSelectedTextColor = FocusedTextColor;
            CustomerSelectedBackground = UnfocusedColor;
            CustomerSelectedTextColor = UnfocusedTextColor;
        }

        /// <summary>
        /// Customer switch clicked
        /// </summary>
        private void CustomerAction()
        {
            MerchantSelectedBackground = UnfocusedColor;
            MerchantSelectedTextColor = UnfocusedTextColor;
            CustomerSelectedBackground = FocusedColor;
            CustomerSelectedTextColor = FocusedTextColor;
        }

        #endregion
    }
}
