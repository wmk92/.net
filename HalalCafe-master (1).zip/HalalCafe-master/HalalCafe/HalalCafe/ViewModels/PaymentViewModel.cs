﻿using HalalCafe.Common;
using HalalCafe.Models;
using HalalCafe.Services;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HalalCafe.ViewModels
{
    public class PaymentViewModel : AppBaseViewModel
    {
        #region Properties

        private string _totalAmount;
        public string TotalAmount {  get => _totalAmount;  set => SetProperty(ref _totalAmount, value);}

        private string _customerName;
        public string CustomerName
        {
            get {return _customerName; }
            set {SetProperty(ref _customerName,value); }

        }
        private string _name;
        public string Name { get => _name; set => SetProperty(ref _name, value); }

        private string _address;
        public string Address { get => _address; set => SetProperty(ref _address, value); }


        private string _emailId;
        public string EmailId  {  get => _emailId;  set => SetProperty(ref _emailId, value);}

        private string _typeOfPay;
        public string TypeOfPay{ get => _typeOfPay; set => SetProperty(ref _typeOfPay, value);}

        private string _submitActionname;
        public string SubmitActionName { get => _submitActionname; set => SetProperty(ref _submitActionname, value);      }

        private string _customerId; 
        private string _customerEmail; 
        private string _walletSessionToken; 
        private string _customerWalletAmount;
        private string _inputAmount;
        #endregion
        #region Commands
        public ICommand SubmitCommand { private set; get; }
        #endregion

        #region Methods

        /// <summary>
        /// Constructor
        /// </summary>
        public PaymentViewModel()
        {
            SubmitCommand = new Command(SubmitAction);
            if (Consts.MerchantPayType == (int)Consts.PayType.Wallet)
            {
                TypeOfPay = App.AssemblyResourceManager.GetString("WalletRecharge");
                SubmitActionName = App.AssemblyResourceManager.GetString("Recharge");
            }
            else
            {
                TypeOfPay = App.AssemblyResourceManager.GetString("Payment"); 
                SubmitActionName = App.AssemblyResourceManager.GetString("Pay"); 
            }
                
        }

        /// <summary>
        /// Parameter constructor
        /// </summary>
        /// <param name="scannedResult"></param>
        public PaymentViewModel(string scannedResult) : this()
        {

            Name = Consts.UserDetails?.first_name;
            EmailId = Consts.UserDetails?.email;

            if (!string.IsNullOrWhiteSpace(Consts.UserDetails?.address1))
                Address = Consts.UserDetails?.address1;
            if (!string.IsNullOrWhiteSpace(Consts.UserDetails?.address2))
                Address += !string.IsNullOrWhiteSpace(Consts.UserDetails?.address1) 
                    ? " , " + Consts.UserDetails?.address2
                    : Consts.UserDetails?.address2;
            else
                Address = "NA";

            try
            {
                if (string.IsNullOrWhiteSpace(scannedResult))
                    Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
                else
                {
                    JObject scannedInfo = JObject.Parse(scannedResult);
                    CustomerName = scannedInfo.ContainsKey("firstname") ? Crypto.Decrypt(scannedInfo["firstname"]?.ToString(),Consts.CryptoKey) : "";
                    _customerEmail = scannedInfo.ContainsKey("email") ? Crypto.Decrypt(scannedInfo["email"]?.ToString(), Consts.CryptoKey) : "";
                    _customerId = scannedInfo.ContainsKey("userId") ? Crypto.Decrypt(scannedInfo["userId"]?.ToString(), Consts.CryptoKey) : "";
                    _customerWalletAmount = scannedInfo.ContainsKey("walletBalance") ? Crypto.Decrypt(scannedInfo["walletBalance"]?.ToString(), Consts.CryptoKey) : "";
                }
                //else if (scannedResult.Contains("~") && scannedResult.Split('~').Length == 4)
                //{
                //    var userInfo = scannedResult.Split('~');
                //    CustomerName = userInfo[0]?.Trim();
                //    _customerEmail = userInfo[1]?.Trim();
                //    _customerId = userInfo[2]?.Trim();
                //    _customerWalletAmount = userInfo[3]?.Trim();
                //}

            }
            catch(Exception ex)
            {
                Debug.WriteLine("Payment View Model construction Exception" +ex.Message);
            }
           
        }


        /// <summary>
        /// Triggers when Pay button tapped
        /// </summary>
        private async void SubmitAction()
        {         

            _inputAmount = !string.IsNullOrWhiteSpace(TotalAmount)
              ? (TotalAmount.Contains("RM") ? TotalAmount.Substring(3)?.Trim() : TotalAmount) : TotalAmount;

            bool IsAmountEnteredValid = double.TryParse(_inputAmount, NumberStyles.Any, CultureInfo.InvariantCulture,
              out double amountEntered);

            bool IsCustomerAmountValid = double.TryParse(_customerWalletAmount, NumberStyles.Any, CultureInfo.InvariantCulture, out double CustomerAmount);

            if (string.IsNullOrWhiteSpace(_inputAmount) ||
                !IsAmountEnteredValid ||
                amountEntered <= 0)
                await Consts.ShowDialog(App.AssemblyResourceManager.GetString("InvalidAmount"));

            else if (
                Consts.MerchantPayType == (int)Consts.PayType.Wallet
                && IsAmountEnteredValid
                && IsCustomerAmountValid
                && (amountEntered + CustomerAmount) > Consts.MaxWalletAmount)
                await Consts.ShowDialog(App.AssemblyResourceManager.GetString("Max1000"));
            
            else if ( //payment
                Consts.MerchantPayType == (int)Consts.PayType.Payment
                && IsAmountEnteredValid
                && IsCustomerAmountValid
                && amountEntered > CustomerAmount)
                await Consts.ShowDialog(App.AssemblyResourceManager.GetString("AmountExceedWallet"));
            else
            {
                StartLoading();
                WalletTransactionAPICall();
            }

        }

        /// <summary>
        /// Find which wallet transaction should call
        /// We have add wallet and pay from wallet
        /// </summary>
        private async void WalletTransactionAPICall()
        {
            try
            {
                if (Consts.InternetAvailability)
                {
                    
                    GetSessionTokenResponse getSessionTokenResponse = await ApiClient.GetInstance().
                    GetWalletSessionToken();
                    if (getSessionTokenResponse == null ||
                        getSessionTokenResponse.status == false) //ERROR
                        await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
                    else if(getSessionTokenResponse.session_token == null)
                        await Consts.ShowDialog(App.AssemblyResourceManager.GetString("InvalidResponse"));
                    else
                    {
                        _walletSessionToken = getSessionTokenResponse.session_token;
                        if (Consts.MerchantPayType == (int)Consts.PayType.Wallet)
                            await AddWalletBalanceAPICall();

                        else if (Consts.MerchantPayType == (int)Consts.PayType.Payment)
                            await ReduceWalletBalanceAPICall();

                    }
                }
            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("Wallet balance details", Consts.UserDetails?.ToString());
                keyValues.Add("Merchant type", Consts.MerchantPayType.ToString());
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("Wallet balance Exception: " + ex.Message);
                await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
            }
            finally
            {
                StopLoading();
            }
        }      


        /// <summary>
        /// Add wallet balance to the customer from merchant
        /// from - merchant
        /// to - customer
        /// money will be added to the customer and deducted from merchant
        /// </summary>
        private async Task AddWalletBalanceAPICall()
        {
           
            if (double.TryParse(_inputAmount, NumberStyles.Any, CultureInfo.InvariantCulture,
              out double amount))
            {
                DateTime dateTime =  DateTime.Now.ToLocalTime();
                Dictionary<string, string> transactionRequest = new Dictionary<string, string>()
                {
                    { "transactiondate", DateTime.Now.ToLocalTime().ToString("yyyy-MM-dd") },
                    { "transactiontime",DateTime.Now.ToLocalTime().ToString("HH:mm:ss")},
                    { "sessiontoken",_walletSessionToken},
                    { "from_user",Consts.UserDetails.walletBalanceResponse.userId.ToString()},
                    { "to_user",_customerId},
                    { "amount",amount.ToString()},
                    { "customerlogin",_customerEmail},
                    { "customername",_customerName},
                    { "merchantlogin",Consts.UserDetails.email.ToString()},
                    { "merchantname",Consts.UserDetails.first_name.ToString()},
                    { "trxtype","Topup"},
                    { "usertype","merchant"}

                };

                AddWalletBalanceRequest addWalletBalanceRequest = new AddWalletBalanceRequest()
                {
                    sessionToken = _walletSessionToken,
                    amountToAdd = amount.ToString(),
                    fromUser = Consts.UserDetails.walletBalanceResponse.userId.ToString(),
                    toUser = _customerId
                };
                RequestWalletBalanceResponse requestWalletBalanceResponse = await ApiClient.GetInstance().
                AddWalletBalance(addWalletBalanceRequest, transactionRequest);

                if (requestWalletBalanceResponse != null && requestWalletBalanceResponse.status) //success
                {
                    PaymentInformation paymentInformation = new PaymentInformation()
                    {
                        TotalAmount = amount,
                        CustomerName = CustomerName,
                        EmailId = EmailId,
                        SessionToken = _walletSessionToken,
                        TransactionDate = $" {transactionRequest["transactiondate"]} {transactionRequest["transactiontime"]}"
                    };

                    await App.NavigationService.
                        SetCurrentRootPage("TransactionDetailsPage", paymentInformation, false);
                }
                else if(requestWalletBalanceResponse != null)
                    await Consts.ShowDialog(requestWalletBalanceResponse?.message?.ToString());
                else
                    await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));

            }
            else
                await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));

        }


        /// <summary>
        /// Invoked when customer pay to the customer
        /// from - customer
        /// to - merchant
        /// Money will be deducted from customer and added to the merchant
        /// </summary>
        /// <returns></returns>
        private async Task ReduceWalletBalanceAPICall()
        {
           
            if (double.TryParse(_inputAmount, NumberStyles.Any, CultureInfo.InvariantCulture,
              out double amount))
            {
                Dictionary<string, string> transactionRequest = new Dictionary<string, string>()
                {
                    { "transactiondate", DateTime.Now.ToLocalTime().ToString("yyyy-MM-dd") },
                    { "transactiontime",DateTime.Now.ToLocalTime().ToString("HH:mm:ss")},
                    { "sessiontoken",_walletSessionToken},
                    { "from_user",_customerId},
                    { "to_user",Consts.UserDetails.walletBalanceResponse.userId.ToString()},
                    { "amount",amount.ToString()},
                    { "customerlogin",_customerEmail},
                    { "customername",_customerName},
                    { "merchantlogin",Consts.UserDetails.email.ToString()},
                    { "merchantname",Consts.UserDetails.first_name.ToString()},
                    { "trxtype","Payment" },
                    { "usertype","customer"}

                };
                ReduceWalletBalanceRequest reduceWalletBalanceRequest = new ReduceWalletBalanceRequest()
                {
                    sessionToken = _walletSessionToken,
                    amountToReduce = amount.ToString(),
                    fromUser = _customerId,
                    toUser = Consts.UserDetails.walletBalanceResponse.userId.ToString()
                };
                RequestWalletBalanceResponse requestWalletBalanceResponse = await ApiClient.GetInstance().
                ReduceWalletBalance(reduceWalletBalanceRequest, transactionRequest);

                if (requestWalletBalanceResponse != null && requestWalletBalanceResponse.status) //success
                {
                    PaymentInformation paymentInformation = new PaymentInformation()
                    {
                        TotalAmount = amount,
                        CustomerName = CustomerName,
                        EmailId = EmailId,
                        SessionToken = _walletSessionToken,
                        TransactionDate = $" {transactionRequest["transactiondate"]} {transactionRequest["transactiontime"]}"
                        
                    };
                    await App.NavigationService.
                        SetCurrentRootPage("TransactionDetailsPage", paymentInformation, false);
                }
                else if (requestWalletBalanceResponse != null)
                    await Consts.ShowDialog(requestWalletBalanceResponse?.message?.ToString());
                else
                    await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));

            }
            else
                await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
        }

        #endregion
    }
}
