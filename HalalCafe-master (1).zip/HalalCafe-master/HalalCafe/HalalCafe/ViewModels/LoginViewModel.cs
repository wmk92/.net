﻿using HalalCafe.Common;
using HalalCafe.Models;
using HalalCafe.Services;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HalalCafe.ViewModels
{
    //Login page for merchant and customer
    public class LoginViewModel : AppBaseViewModel
    {
        #region Properties      
      
        private LoginEntry _loginView;      
        public LoginEntry LoginView
        {
            get { return _loginView; }
            set { SetProperty(ref _loginView, value); }
        }

        private string _email;
        public string Email
        {
            get { return _email; }
            set
            {
                SetProperty(ref _email, value);
            }
        }

        private string _password;
        public string Password
        {
            get { return _password; }
            set
            {
                SetProperty(ref _password, value);
            }
        }


        #endregion

        #region Commands
        public ICommand LoginCommand => new Command(LoginAction);
        public ICommand NavRegisterCommand { get; private set; }

     

        #endregion
        #region Methods
        public LoginViewModel()
        {
            LoginView = new LoginEntry();
            NavRegisterCommand = new Command(NavRegisterAction);
            Consts.CustomerType = string.Empty;
            Consts.SelectedTransaction = null;

            //Add username and password from stored settings if exists
            LoginView.Email.Name = Settings.LoginUsername;
            LoginView.Password.Name = Settings.LoginPassword;

        }

        /// <summary>
        /// Login button submit
        /// </summary>
        private  void LoginAction()
        {


            if (string.IsNullOrWhiteSpace(LoginView.Email.Name?.Trim()) ||
              !Regex.IsMatch(LoginView.Email.Name?.Trim(), Consts.EmailPattern))
                LoginView.Email.IsNotValid = true;

            else if (string.IsNullOrWhiteSpace(LoginView.Password.Name?.Trim()))
                LoginView.Password.IsNotValid = true;

            else if (Consts.InternetAvailability)
                CallLoginAPI();

            //await App.NavigationService.SetCurrentRootPage("MainMasterDetailPage", false);


        }


        /// <summary>
        /// Call Login API
        /// </summary>
        private async void CallLoginAPI()
        {
            Dictionary<string, string> loginDetails = null;
            try
            {
                StartLoading();
                await Task.Delay(1000); //as we are getting immediate response and to avoid sluggish
                loginDetails = new Dictionary<string, string>
                {
                        { "email", LoginView.Email.Name?.Trim() },
                        { "password",LoginView.Password.Name?.Trim()},
                };

                LoginAPIWebResponse userLoginResponse = await ApiClient.GetInstance().LoginAuth(loginDetails);

                //Validate API response
                if (userLoginResponse == null || !userLoginResponse.status)
                    await Consts.ShowDialog(userLoginResponse.message);
                else
                {
                    //TODO change below line once customer type updated on the server
                    Consts.CustomerType = userLoginResponse.data.usertype;
                    Consts.UserDetails = userLoginResponse.data;
                    Consts.UserDetails.password = LoginView.Password.Name?.Trim(); //used for wallet balance
                    Settings.LoginUsername = loginDetails["email"];
                    Settings.LoginPassword = loginDetails["password"];
                    await App.NavigationService.SetCurrentRootPage("MainMasterDetailPage", false);
                }
            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("User Login Action post body details", loginDetails?.ToString());
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("User Login Exception: " + ex.Message);
                await Consts.ShowDialog(App.AssemblyResourceManager.GetString("UnexpectedError"));
            }
            finally {

                StopLoading();
            }

        }

        /// <summary>
        /// Navigatio to register
        /// </summary>
        private void NavRegisterAction()
        {
            App.NavigationService.NavigateAsync("SignUp", false);
        }

        
        #endregion
    }
}
