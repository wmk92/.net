﻿using HalalCafe.Common;
using HalalCafe.Controls;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using Xamarin.Forms;

namespace HalalCafe.Behaviors
{

    /// <summary>
    /// Entries inline validations messages
    /// </summary>
    public class EntryEmptyBehaviour : Behavior<CustomEntry>
    {


        public static readonly BindableProperty EntryTypeProperty = 
            BindableProperty.Create(nameof(EntryType),typeof(string),typeof(EntryEmptyBehaviour),null,BindingMode.TwoWay);

        public string EntryType
        {
            get {return (string) GetValue(EntryTypeProperty); }
            set { SetValue(EntryTypeProperty,value); }
        }

        CustomEntry control;
        Xamarin.Forms.Color _textColor;
        
        Label showEntryHintLabel;
        Span showEntryHintSpan;

        protected override void OnAttachedTo(CustomEntry bindable)
        {
            base.OnAttachedTo(bindable);
            bindable.TextChanged += HandleTextChanged;
            bindable.PropertyChanged += OnPropertyChanged;
            bindable.Unfocused += HandleUnfocused;
           
            
            control = bindable;
            _textColor = bindable.TextColor;
            
            showEntryHintLabel = (bindable.ErrorHintText as Label);
            if (showEntryHintLabel == null)
                showEntryHintSpan = (bindable.ErrorHintText as Span);
        }

       

        private void HandleUnfocused(object sender, FocusEventArgs e)
        {
            CustomEntry entry = (CustomEntry)sender;
            if(string.IsNullOrEmpty(entry.Text))
                ((CustomEntry)sender).IsBorderErrorVisible = true;
        }

        void HandleTextChanged(object sender, TextChangedEventArgs e)
        {

            Entry entry = (Entry)sender;
            if (!string.IsNullOrEmpty(e.NewTextValue))
            {

                if (EntryType.Equals("email"))
                {
                   
                    if (!Regex.IsMatch(entry.Text?.Trim(), Consts.EmailPattern))
                    {
                        ((CustomEntry)sender).IsBorderErrorVisible = true;
                        entry.Focus();
                    }
                    else
                        ((CustomEntry)sender).IsBorderErrorVisible = false;
                }
                else
                    ((CustomEntry)sender).IsBorderErrorVisible = false;
            }
            
        }

        protected override void OnDetachingFrom(CustomEntry bindable)
        {
            base.OnDetachingFrom(bindable);
            bindable.TextChanged -= HandleTextChanged;
            bindable.PropertyChanged -= OnPropertyChanged;
        }

        void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == CustomEntry.IsBorderErrorVisibleProperty.PropertyName && control != null)
            {
                if (control.IsBorderErrorVisible)
                {
                    control.TextColor = control.BorderErrorColor;
                    if (showEntryHintLabel == null)
                        showEntryHintSpan.TextColor = control.BorderErrorColor;
                    else
                        showEntryHintLabel.TextColor = control.BorderErrorColor;
                    control.Focus();
                }
                else
                {
                    if (showEntryHintLabel == null)
                        showEntryHintSpan.TextColor = _textColor;
                    else
                        showEntryHintLabel.TextColor = _textColor;
                    control.TextColor = _textColor;
                }

            }
        }
    }
}
