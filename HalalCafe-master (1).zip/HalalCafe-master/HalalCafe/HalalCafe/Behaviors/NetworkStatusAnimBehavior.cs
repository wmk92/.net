﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using Xamarin.Forms;

namespace HalalCafe.Behaviors
{
    /// <summary>
    /// Apply animation to the network status box
    /// </summary>
    public class NetworkStatusAnimBehavior : Behavior<ContentView>
    {

        ContentView control;
        protected override void OnAttachedTo(ContentView bindable)
        {
            base.OnAttachedTo(bindable);
            control = bindable;
            control.PropertyChanged += OnPropertyChanged;
        }

        private void OnPropertyChanged(Object sender, PropertyChangedEventArgs e)
        {
            if(e.PropertyName == StackLayout.BindingContextProperty.PropertyName)
            {
                if ((bool)control.BindingContext == true)
                {//show
                    FadeOutAnimation(); 
                }
                else
                {
                    FadeInAnimation();
                }
            }
        }

        protected override void OnDetachingFrom(ContentView bindable)
        {
            base.OnDetachingFrom(bindable);
            control.PropertyChanged -= OnPropertyChanged;
        }

        private async void FadeInAnimation()
        {
            control.IsVisible = true;
            await control.FadeTo(1, 1000, Easing.Linear);
            
        }

        private async void FadeOutAnimation()
        {
            await control.FadeTo(0, 1000, Easing.Linear);
            control.IsVisible = false;
        }
    }
}
