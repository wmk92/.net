﻿using HalalCafe.ViewModels;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Xamarin.Forms;

namespace HalalCafe.Behaviors
{
    class DateSelectedBehaviour :  Behavior<DatePicker>
    {

        public static readonly BindableProperty DateTypeProperty =
          BindableProperty.Create(nameof(DateType), typeof(string), typeof(DateSelectedBehaviour), null, BindingMode.TwoWay);

        public string DateType
        {
            get { return (string)GetValue(DateTypeProperty); }
            set { SetValue(DateTypeProperty, value); }
        }
        DatePicker control { get; set; }
        //private readonly string FullDateFormat = "dddd, MMMM d, yyyy";
        private DateTime selectedDate;
        private FilterViewModel filterViewModel;

       


        protected override void OnAttachedTo(DatePicker bindable)
        {
            base.OnAttachedTo(bindable);
            bindable.DateSelected += HandleDateSelected;
          
            control = bindable;
            bindable.BindingContextChanged += OnBindingContextChanged;



        }

        private void HandleDateSelected(object sender, DateChangedEventArgs e)
        {

            DatePicker datePicker = sender as DatePicker;
            selectedDate = datePicker.Date;

            if (filterViewModel != null)
                //filterViewModel.updateDates(selectedDate,DateType);
            
            Debug.WriteLine($"SelectedDate = {selectedDate.ToString()}");


        }

        void OnBindingContextChanged(object sender, EventArgs e)
        {
            OnBindingContextChanged();
        }

        protected override void OnBindingContextChanged()
        {
            base.OnBindingContextChanged();
            

            filterViewModel = control.BindingContext as FilterViewModel;

        }

        protected override void OnDetachingFrom(DatePicker bindable)
        {
            base.OnDetachingFrom(bindable);
            bindable.DateSelected -= HandleDateSelected;
            bindable.BindingContextChanged -= OnBindingContextChanged;

        }
    }
}
