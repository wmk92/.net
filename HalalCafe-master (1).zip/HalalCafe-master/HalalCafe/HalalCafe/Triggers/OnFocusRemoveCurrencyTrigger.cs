﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using Xamarin.Forms;

namespace HalalCafe.Triggers
{
    public class OnFocusRemoveCurrencyTrigger : TriggerAction<Entry>
    {
        protected override void Invoke(Entry entry)
        {
            if (!string.IsNullOrWhiteSpace(entry.Text) && entry.Text.Contains("RM"))
            {
               entry.Text =  entry.Text.Substring(3).Trim();
            }
        }
    }
}
