﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using Xamarin.Forms;

namespace HalalCafe.Triggers
{
    public class UnFocusAddCurrencyTrigger : TriggerAction<Entry>
    {
        protected override void Invoke(Entry entry)
        {
            if (!string.IsNullOrWhiteSpace(entry.Text) && double.TryParse(entry.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out double result))
            {
                entry.Text = string.Format(CultureInfo.InvariantCulture," RM {0:0.00} ", result);
            }
        }
    }
}
