﻿using HalalCafe.Common;
using HalalCafe.ViewModels;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using ZXing.QrCode;

namespace HalalCafe.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class CustomerHomePage : ContentPage
	{
        CustomerHomeViewModel customerHomeViewModel;
        bool navigatedToQRPage = false;

        public CustomerHomePage ()
		{
			InitializeComponent ();
		}

        /// <summary>
        /// Binding ViewModel Context
        /// </summary>
        protected override void OnAppearing()
        {
            base.OnAppearing();
            if (customerHomeViewModel == null)
            {               
                this.BindingContext = customerHomeViewModel = new CustomerHomeViewModel();
            }
            else
                customerHomeViewModel.CallGetWalletBalanceAPI();

            navigatedToQRPage = false;
            if (!Accelerometer.IsMonitoring)
            {
                Accelerometer.ShakeDetected -= Device_OnShaked;
                Accelerometer.ShakeDetected += Device_OnShaked;
                Accelerometer.Start(SensorSpeed.Default);
            }
        }

        private void Device_OnShaked(object sender, EventArgs e)
        {
            if(!navigatedToQRPage)
                customerHomeViewModel.NavToQRPageCommand.Execute(string.Empty);
            navigatedToQRPage = true;
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            Accelerometer.ShakeDetected -= Device_OnShaked;
            Accelerometer.Stop();
        }

        protected override bool OnBackButtonPressed()
        {
            Device.BeginInvokeOnMainThread(async() =>
            {
                bool result = await Consts.ShowPromtDialog(App.AssemblyResourceManager.GetString("ExitPrompt"));
                if (result)
                {
                    Process.GetCurrentProcess().CloseMainWindow();
                    Process.GetCurrentProcess().Close();
                }
                    
            });
            return true;
            
        }
    }
}