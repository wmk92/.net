﻿using HalalCafe.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HalalCafe.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class HistoryPage : ContentPage
	{

        HistoryViewModel historyViewModel = null;
        public HistoryPage ()
		{
			InitializeComponent ();
		}

        protected override void OnAppearing()
        {
            base.OnAppearing();
            if (historyViewModel == null)
                this.BindingContext = historyViewModel = new HistoryViewModel();
                
            historyViewModel.setSelectedTransactions();
            
        }

        protected override bool OnBackButtonPressed()
        {
            historyViewModel.BackAction();
            return true;
        }

    }
}