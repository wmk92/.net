﻿using HalalCafe.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HalalCafe.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class PaymentPage : ContentPage
	{
        PaymentViewModel paymentViewModel;
        private string _scannedResult;
        public PaymentPage ()
		{
			InitializeComponent ();
		}

        public PaymentPage (string scannedResult) : this()
		{
            this._scannedResult = scannedResult;

        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            if (paymentViewModel == null)
                this.BindingContext = paymentViewModel = new PaymentViewModel(_scannedResult);
        }
    }
}