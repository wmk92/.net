﻿using HalalCafe.Common;
using HalalCafe.Models;
using HalalCafe.ViewModels;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HalalCafe.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MainMasterDetailPageMaster : ContentPage
    {
        public MainMasterDetailPageMaster()
        {
            InitializeComponent();            
            
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            if(BindingContext == null)
                BindingContext = new MainMasterDetailMasterViewModel(this);
        }


        /// <summary>
        /// Add Wallet amount to the custom slider
        /// </summary>
        public void AddWalletAmountLevel(double amount)
        {
            lblSliderValueIndicator.Text = string.Format(CultureInfo.InvariantCulture,"RM {0:0.00}", amount) + 
                ((Consts.CustomerType?.ToLower()?.Trim() == "customer") ? " of 1000(maximum)" : "");

            double ratio = (double)amount / (int)((Consts.CustomerType?.ToLower()?.Trim() == "customer") 
                ? 1000 : (amount+1000)); //TODO
             AbsoluteLayout.SetLayoutBounds(WalletAmountLevel, new Rectangle(0, 0, ratio, 5));

        }
       
    }
}