﻿using HalalCafe.Models;
using HalalCafe.ViewModels;
using Lottie.Forms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HalalCafe.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class TransactionDetailsPage : ContentPage
	{
        TransactionDetailsViewModel transactionDetailsViewModel;
        private PaymentInformation _paymentInformation;
        public TransactionDetailsPage ()
		{
			InitializeComponent ();
           
        }
        public TransactionDetailsPage (PaymentInformation paymentInformation) : this()
		{
            this._paymentInformation = paymentInformation;

        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            if (transactionDetailsViewModel == null)
            {
                this.BindingContext = transactionDetailsViewModel = new TransactionDetailsViewModel(_paymentInformation);
            }
        }

        protected override bool OnBackButtonPressed()
        {
            return true;
        }
    }
}