﻿using HalalCafe.Common;
using HalalCafe.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HalalCafe.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MainMasterDetailPage : MasterDetailPage
    {
        public MainMasterDetailPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this,false);
            var page = Consts.CustomerType?.ToLower()?.Trim() == "customer" ? (Page)new CustomerHomePage() : (Page)new MerchantHomePage();
            Master.Detail = new NavigationPage(page) ; // Customer
          
        }
     
    }
}