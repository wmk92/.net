﻿using HalalCafe.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HalalCafe.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class DateFilter : ContentPage
	{
        FilterViewModel _filterViewModel = null;

		public DateFilter ()
		{
			InitializeComponent ();
            NavigationPage.SetHasNavigationBar(this, true);
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            this.BindingContext = _filterViewModel = new FilterViewModel(); 

           
        }
       

       
    }
}