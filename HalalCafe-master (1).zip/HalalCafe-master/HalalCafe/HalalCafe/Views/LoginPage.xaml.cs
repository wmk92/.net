﻿using HalalCafe.ViewModels;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HalalCafe.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class LoginPage : ContentPage
	{
        LoginViewModel loginViewModel;
        public LoginPage ()
		{
			InitializeComponent ();
            NavigationPage.SetHasNavigationBar(this,false);          

        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            if(loginViewModel == null)
                this.BindingContext = loginViewModel = new LoginViewModel();
            else
                loginViewModel.CheckInternetAvailability();
        }

    }
}