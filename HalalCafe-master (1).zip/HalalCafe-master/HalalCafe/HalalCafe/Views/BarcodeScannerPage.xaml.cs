﻿using HalalCafe.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HalalCafe.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class BarcodeScannerPage : ContentPage
	{
        BarcodeScannerViewModel barcodeScannerViewModel;
        private int _scanType;
        public BarcodeScannerPage ()
		{
			InitializeComponent ();
		}

        public BarcodeScannerPage (int scanType):this()
		{
            _scanType = scanType;

        }
        /// <summary>
        /// Binding ViewModel Context
        /// </summary>
        protected override void OnAppearing()
        {
            base.OnAppearing();
           // NavigationPage.SetHasNavigationBar(this, false);
            if (barcodeScannerViewModel == null)
            {
                this.BindingContext = barcodeScannerViewModel = new BarcodeScannerViewModel(_scanType);
            }
        }
    }
}