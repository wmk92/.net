﻿using HalalCafe.Common;
using HalalCafe.ViewModels;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HalalCafe.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class MerchantHomePage : ContentPage
	{
        MerchantHomeViewModel merchantHomeViewModel;
        public MerchantHomePage ()
		{
			InitializeComponent ();
		}
        /// <summary>
        /// Binding ViewModel Context
        /// </summary>
        protected override void OnAppearing()
        {
            base.OnAppearing();
            if (merchantHomeViewModel == null)
            {
                this.BindingContext = merchantHomeViewModel = new MerchantHomeViewModel();
            }
            else if (Consts.ScannedResult != null)
            {                
                merchantHomeViewModel.SetBarcodeResult(Consts.ScannedResult);
                Consts.ScannedResult = null; //reset
            }
        }

        protected override bool OnBackButtonPressed()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                bool result = await Consts.ShowPromtDialog(App.AssemblyResourceManager.GetString("ExitPrompt"));
                if (result)
                {
                    Process.GetCurrentProcess().CloseMainWindow();
                    Process.GetCurrentProcess().Close();
                }

            });
            return true;

        }
    }
}