﻿using HalalCafe.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using ZXing.QrCode;

namespace HalalCafe.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class CustomerQRPage : ContentPage
	{
        CustomerQRPageViewModel customerQRPageViewModel;
        public CustomerQRPage ()
		{
			InitializeComponent ();
            if (customerQRPageViewModel == null)
            {
                this.BindingContext = customerQRPageViewModel = new CustomerQRPageViewModel();
            }
        }

        /// <summary>
        /// Binding ViewModel Context
        /// </summary>
        protected override void OnAppearing()
        {
            base.OnAppearing();

            lblBarcodeImage.BarcodeOptions = new QrCodeEncodingOptions
            {
                Height = 200,
                Width = 200,
                Margin = 0
            };


        }
    }
}