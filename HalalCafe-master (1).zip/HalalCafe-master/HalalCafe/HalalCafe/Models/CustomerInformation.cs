﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HalalCafe.Models
{
    public class CustomerInformation
    {
        public double TotalAmount { get; set; }
        public string CustomerName { get; set; }
        public string EmailId { get; set; }

        public string Address { get; set; }
    }

    public class CustomerQRInfo
    {  
        public string FirstName { get; set; }
        public string Email { get; set; }
        public string UserId { get; set; }

    }
}
