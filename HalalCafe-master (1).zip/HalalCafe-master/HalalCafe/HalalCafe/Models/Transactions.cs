﻿using HalalCafe.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace HalalCafe.Models
{
    public class Transactions : AppBaseViewModel
    {
        private string _transactionNumber;
        public string TransactionNumber
        {
            get { return _transactionNumber; }
            set { SetProperty(ref _transactionNumber, value); }
        }

        private bool isSelected;

        public bool IsSelected
        { get { return isSelected; }
            set {SetProperty(ref isSelected,value); }
        }
    }
}
