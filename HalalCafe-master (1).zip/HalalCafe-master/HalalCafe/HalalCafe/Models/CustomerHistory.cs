﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HalalCafe.Models
{
    class CustomerHistory
    {


        public string Cost { get; set; }

        public string Date { get; set; }

        public string DateTime { get; set; }

        public string ReferenceNo { get; set; }
    }
}
