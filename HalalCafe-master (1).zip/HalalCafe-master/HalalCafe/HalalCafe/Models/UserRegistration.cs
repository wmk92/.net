﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HalalCafe.Models
{
    /// <summary>
    /// Registration API response
    /// </summary>
    public class RegisterAPIWebResponse
    {
        public bool status { get; set; }
        public string message { get; set; }
        public int data { get; set; }
        public string email_link { get; set; }
        public string session_token { get; set; }
    }

    /// <summary>
    /// Change password API request
    /// </summary>
    public class ChangePasswordRequest
    {
        public int userId { get; set; }
        public string currentPassword { get; set; }
        public string newpassword { get; set; }
        public string repeatnewpassword { get; set; }
    }


    /// <summary>
    /// Create Dealer API request
    /// </summary>
    public class CreateDealerRequest
    {
        public string sessionToken { get; set; }
        public string tenant { get; set; }
        public string distributorName { get; set; }
        public string subdistributorName { get; set; }
        public string dealerName { get; set; }
        public string contactName { get; set; }
        public string contactPhone { get; set; }
        public string contactEmail { get; set; }
        public string userName { get; set; }
    }


    /// <summary>
    /// Create dealer API response
    /// </summary>
    public class CreateDealerResponse
    {
        public int entityId { get; set; }
        public string entityName { get; set; }
        public string message { get; set; }
        public bool createdStatus { get; set; }
        public int templateId { get; set; }
        public int userId { get; set; }
    }

    //success
    //{"entityId":159,"entityName":"Evoke11","message":"Dealer Created Successfully","createdStatus":true,"templateId":0,"userId":162}
    //Error
    //{"entityId":150,"entityName":"Evoke1","message":"Dealer Already Exists","createdStatus":false,"templateId":0,"userId":0}
}
