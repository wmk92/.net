﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HalalCafe.Models
{
    public class GetSessionTokenResponse
    {
        public bool status { get; set; }
        public bool message { get; set; }
        public string session_token { get; set; }
    }

    public class AddWalletBalanceRequest
    {
        public string sessionToken { get; set; }
        public string fromUser { get; set; }
        public string toUser { get; set; }
        public string amountToAdd { get; set; }
    }

    public class ReduceWalletBalanceRequest
    {
        public string sessionToken { get; set; }
        public string fromUser { get; set; }
        public string toUser { get; set; }
        public string amountToReduce { get; set; }
    }

    public class RequestWalletBalanceResponse
    {
        public bool status { get; set; }
        public string message { get; set; }
        public int fromUserId { get; set; }
        public int toUserId { get; set; }
        public double amountTransferred { get; set; }
        public double senderBalBefore { get; set; }
        public double senderBalAfter { get; set; }
        public double receiverBalBefore { get; set; }
        public double receiverBalAfter { get; set; }
        public int transactionBy { get; set; }

    }

    public class TransactionResponse {

        public bool status { get; set; }
        public string message { get; set; }
        public int data { get; set; }
    }

    public class PaymentInformation {
        public double TotalAmount { get; set; }
        public string CustomerName { get; set; }
        public string EmailId { get; set; }
        public string TransactionDate { get; set; }
        public string Address { get; set; }
        public string SessionToken { get; set; }

    }

}
