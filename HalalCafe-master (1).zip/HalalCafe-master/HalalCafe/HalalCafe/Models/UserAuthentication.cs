﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HalalCafe.Models
{
    /// <summary>
    /// Login response data
    /// </summary>
    public class LoginResponseData
    {
        public string id { get; set; }
        public string first_name { get; set; }
        public string last_name { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public string phone { get; set; }
        public string created { get; set; }
        public string modified { get; set; }
        public string status { get; set; }
        public string address1 { get; set; }
        public string address2 { get; set; }
        public string state { get; set; }
        public string country { get; set; }
        public string city { get; set; }
        public string usertype { get; set; }
        public WalletBalanceResponse walletBalanceResponse { get; set; } // This is to hold wallet balance data of another API response

    }


    /// <summary>
    /// Login API response
    /// </summary>
    public class LoginAPIWebResponse
    {
        public bool status { get; set; }
        public string message { get; set; }
        public LoginResponseData data { get; set; }
    }


    public class WalletBalanceResponse
    {
        public int userId { get; set; }
        public string userName { get; set; }
        public string sessionToken { get; set; }
        public double walletBalance { get; set; }
        public string businessName { get; set; }
    }

    public class ErrorResponse
    {
        public bool status { get; set; }
        public string error { get; set; }
    }
    //ERROR
    //{"userId":0,"walletBalance":0.0}
}
