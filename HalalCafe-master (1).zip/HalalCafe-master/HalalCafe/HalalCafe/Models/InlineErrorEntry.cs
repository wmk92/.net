﻿ using MvvmHelpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace HalalCafe.Models
{
    public class InlineErrorEntry : BaseViewModel
    {
        private string _name;
        public string Name { get { return _name; } set { SetProperty(ref _name, value); } }

        private bool _isNotValid;
        public bool IsNotValid { get { return _isNotValid; } set { SetProperty(ref _isNotValid, value); } }

        private string _notValidMessageError;
        public string NotValidMessageError { get { return _notValidMessageError; } set { SetProperty(ref _notValidMessageError, value); } }



    }

    /// <summary>
    /// For Login Page
    /// </summary>
    public class LoginEntry : BaseViewModel
    {

        private InlineErrorEntry _email = new InlineErrorEntry()
        { NotValidMessageError = App.AssemblyResourceManager.GetString("InvalidEmail"),
        };
        public InlineErrorEntry Email { get { return _email; } set { SetProperty(ref _email, value); } }

        private InlineErrorEntry _password = new InlineErrorEntry()
        { NotValidMessageError = App.AssemblyResourceManager.GetString("InvalidPassword") };
        public InlineErrorEntry Password { get { return _password; } set { SetProperty(ref _password,value); } }

    }


    //For SignUp Page
    public class SignUpEntry : BaseViewModel
    {

        private InlineErrorEntry _firstName = new InlineErrorEntry()
        { NotValidMessageError = App.AssemblyResourceManager.GetString("InvalidFirstName") ,};
        public InlineErrorEntry FirstName
        {
            get { return _firstName; }
            set { SetProperty(ref _firstName, value); }
        }


        private InlineErrorEntry _lastName = new InlineErrorEntry()
        {
            NotValidMessageError = App.AssemblyResourceManager.GetString("InvalidLastName")
        };

        public InlineErrorEntry LastName
        {
            get { return _lastName; }
            set { SetProperty(ref _lastName, value); }
        }

        private InlineErrorEntry _email = new InlineErrorEntry()
        {
            NotValidMessageError = App.AssemblyResourceManager.GetString("InvalidEmail")
        };

        public InlineErrorEntry Email
        {
            get { return _email; }
            set { SetProperty(ref _email, value); }
        }

        private InlineErrorEntry _password = new InlineErrorEntry()
        {
            NotValidMessageError = App.AssemblyResourceManager.GetString("InvalidPassword")
        };

        public InlineErrorEntry Password
        {
            get { return _password; }
            set { SetProperty(ref _password, value); }
        }

        private InlineErrorEntry _mobile = new InlineErrorEntry()
        {
            NotValidMessageError = App.AssemblyResourceManager.GetString("InvalidMobile"),
            Name = string.Empty
        };
        public InlineErrorEntry Mobile
        {
            get { return _mobile; }
            set { SetProperty(ref _mobile, value); }
        }

      


    }

}
