﻿using HalalCafe.Common;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace HalalCafe.Models
{
   public class TransactionHistory
    {     

        public string id { get; set; }
        public string transactiondate { get; set; }
        public string transactiontime { get; set; }
        public string sessiontoken { get; set; }
        public string from_user { get; set; }
        public string to_user { get; set; }
        public string amount { get; set; }
        public string customerlogin { get; set; }
        public string customername { get; set; }
        public string merchantlogin { get; set; }
        public string merchantname { get; set; }
        public string trxtype { get; set; }

        public string transactiondatetime
        {
            get => ConvertToNumberOfDays();
            set { }
        }
        public string walletAmount
        {
            get
            {
                if (double.TryParse(amount, NumberStyles.Any, CultureInfo.InvariantCulture, out double amountParsed))
                    return string.Format(CultureInfo.InvariantCulture, "{0:0.00}", amountParsed);
                return amount;

            }
            set {}
        }


        public string referencenumber { get { return sessiontoken.Substring(7); } set { } }

        private string ConvertToNumberOfDays()
        {
            try
            {
                DateTime currentDate = DateTime.Parse(DateTime.Now.ToLocalTime().ToString("yyyy-MM-dd"));
                bool isTransactionDateValid = DateTime.TryParseExact(transactiondate?.Trim(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime transactionDate);
                bool isTransactionTimeValid = DateTime.TryParseExact(transactiontime?.Trim(), "HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime transactionTime);

                if (!isTransactionDateValid || !isTransactionTimeValid) //failed
                {
                    return "---";
                }

                double result = (currentDate - transactionDate).TotalDays;

                if (result < 0) //future date
                    return "---";
                else if (result == 0) //same day
                    return transactionTime.ToString("hh:mm tt ");
                else if (result <= 7) //same week
                    return result + ((result == 1) ? " day ago" : " days ago");
                else
                    return transactionDate.ToString("dd MMM");
            }catch(Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("Transaction Date", transactiondate);
                Consts.TrackError(ex,keyValues);
            }

            return "---";

        }

    }

    public class TransactionHistoryListResponse
    {
        public List<TransactionHistory> TransactionHistoryList { get; set; } = new List<TransactionHistory>();
        public bool status { get { return TransactionHistoryList!=null && TransactionHistoryList.Count > 0; } set { } }
        public string message { get; set; }
    }

    public class TransactionErrorResponse
    {
        public bool status { get; set; }
        public string message { get; set; }
    }

}
