﻿using HalalCafe.Common;
using HalalCafe.Interfaces;
using HalalCafe.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace HalalCafe.Services
{
    /// <summary>
    /// Contains all API calls
    /// </summary>
    public class ApiClient : IApiClient
    {
        private static ApiClient _apiClient;
        public static IApiClient GetInstance()
        {
            return _apiClient ?? (_apiClient = new ApiClient());
        }           


        /// <summary>
        /// Register API
        /// POST Form data
        /// </summary>
        /// <param name="userDetailsRequest"></param>
        /// <returns></returns>
        public async Task<RegisterAPIWebResponse> RegisterUser(Dictionary<string, string> userDetailsRequest,
            CreateDealerRequest createDealerRequest)
        {
            RegisterAPIWebResponse userRegisterResponse = null;
            try
            {
                using (HttpClient httpClient =  CreateClient())
                {


                    var formContent = new FormUrlEncodedContent(userDetailsRequest);
                    var response = httpClient.PostAsync(Consts.RegistrationURL, formContent).Result;
                    string contents = await response.Content.ReadAsStringAsync();
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        userRegisterResponse = JsonConvert.DeserializeObject<RegisterAPIWebResponse>(contents);
                        //Create Dealer API Call
                        createDealerRequest.sessionToken = userRegisterResponse.session_token;
                        CreateDealerResponse createDealerResponse = await CreateDealer(createDealerRequest);

                        if (!createDealerResponse.createdStatus)  //failed
                            userRegisterResponse = RegisterError(createDealerResponse.message);

                        else if (await ChangePassword(new ChangePasswordRequest()  //success
                        {
                            userId = createDealerResponse.userId,
                            currentPassword = $"{createDealerRequest.contactEmail}@MPApp",
                            newpassword = userDetailsRequest["password"]?.ToString(),
                            repeatnewpassword = userDetailsRequest["password"]?.ToString()
                        }))
                            await CloseSession(createDealerRequest.sessionToken);
                        else
                            userRegisterResponse = RegisterError(App.AssemblyResourceManager.GetString("UnexpectedError"));
                    }
                    else
                        userRegisterResponse = RegisterError(contents);
                }
            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("User Registraton", userDetailsRequest?.ToString());
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("Register User Exception: " + ex.Message);
                userRegisterResponse = RegisterError(App.AssemblyResourceManager.GetString("UnexpectedError"));
            }
            return userRegisterResponse;
        }

        /// <summary>
        /// To Add customer to the dealer
        ///  called  immediately after registration API has been called
        /// </summary>
        /// <param name="createDealerRequest"></param>
        /// <returns></returns>
        public async Task<CreateDealerResponse> CreateDealer(CreateDealerRequest createDealerRequest)
        {
            CreateDealerResponse createDealerResponse = null;
            try
            {
                using (HttpClient httpClient = CreateClient())
                {
                    string inputData = JsonConvert.SerializeObject(createDealerRequest);
                    HttpContent httpContent = new StringContent(inputData);
                    httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    var response = await httpClient.PostAsync(Consts.CreateDealerURL, httpContent);
                    string respData = await response.Content.ReadAsStringAsync();
                    if (response.IsSuccessStatusCode && response.StatusCode == System.Net.HttpStatusCode.Created)
                    {
                        createDealerResponse = JsonConvert.DeserializeObject<CreateDealerResponse>(respData);
                    }
                    else
                        createDealerResponse = new CreateDealerResponse { createdStatus = false, message = respData };
                }

            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("CreateDealer", createDealerRequest?.ToString());
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("Create Dealer Exception: " + ex.Message);
                createDealerResponse = new CreateDealerResponse { createdStatus = false, message = App.AssemblyResourceManager.GetString("UnexpectedError") };
            }

            return createDealerResponse;

        }

        /// <summary>
        /// Called immediatley after CreateDealer API called
        /// </summary>
        /// <param name="ChangePasswordRequest"></param>
        /// <returns></returns>
        public async Task<bool> ChangePassword(ChangePasswordRequest changePasswordRequest)
        {
            try
            {
                using (HttpClient httpClient = CreateClient())
                {
                    string inputData = JsonConvert.SerializeObject(changePasswordRequest);
                    HttpContent httpContent = new StringContent(inputData);
                    httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    var response = await httpClient.PostAsync(Consts.ChangePasswordURL, httpContent);
                    if (response.IsSuccessStatusCode && response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string respData = await response.Content.ReadAsStringAsync();
                        return Boolean.TryParse(respData?.Trim(), out bool result);
                    }
                   
                }

            }
            catch(Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("Change Password Request", changePasswordRequest?.ToString());
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("Change Password Exception: " + ex.Message);                
            }
            return false;
        }

        /// <summary>
        /// close my pay gateway session 
        /// </summary>
        /// <param name="sessionToken"></param>
        /// <returns></returns>
        public async Task<bool> CloseSession(string sessionToken)
        {
            try
            {
                using (HttpClient httpClient = CreateClient())
                {
                    var response = await httpClient.GetAsync($"{Consts.CloseSessionURL}/{sessionToken}");
                    if (response.IsSuccessStatusCode && response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string respData = await response.Content.ReadAsStringAsync();
                     //   return Boolean.TryParse(respData?.Trim(), out bool result); //Not required to alert the user
                    }

                }

            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("sessionToken", $"{Consts.CloseSessionURL}/{sessionToken}");
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("Close session exception: " + ex.Message);
            }
            return true;
        }

        /// <summary>
        /// User Login Authentication
        /// Gives user profile
        /// </summary>
        /// <param name="loginDetailsRequest"></param>
        /// <returns></returns>
        public async Task<LoginAPIWebResponse> LoginAuth(Dictionary<string, string> loginDetailsRequest)
        {
            LoginAPIWebResponse loginAPIWebResponse = null;
            try
            {
                using (HttpClient httpClient = CreateClient())
                {

                    var formContent = new FormUrlEncodedContent(loginDetailsRequest);

                    var response = httpClient.PostAsync(Consts.LoginURL, formContent).Result;
                    string contents = await response.Content.ReadAsStringAsync();
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        loginAPIWebResponse = JsonConvert.DeserializeObject<LoginAPIWebResponse>(contents);
                        //Call wallet balance to check whether it is giving correct result in login page itself
                        WalletBalanceResponse walletBalanceResponse = await WalletBalance(loginDetailsRequest["email"], 
                            loginDetailsRequest["password"]);
                        if(walletBalanceResponse == null || walletBalanceResponse.userId == 0)
                            loginAPIWebResponse = LoginError(App.AssemblyResourceManager.GetString("LoginFailed"));
                    }
                    else
                        loginAPIWebResponse = LoginError(contents);
                }
            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("Login Auth", loginDetailsRequest?.ToString());
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("Login auth Exception: " + ex.Message);
                loginAPIWebResponse = LoginError(App.AssemblyResourceManager.GetString("UnexpectedError"));
            }

            return loginAPIWebResponse;
        }


        /// <summary>
        /// Fetch Wallet Balance
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public async  Task<WalletBalanceResponse> WalletBalance(string userName, string password)
        {
            WalletBalanceResponse walletBalanceResponse = null;
            try
            {
                using (HttpClient httpClient = CreateClient())
                {
                    var response = await httpClient.GetAsync($"{Consts.WalletBalanceURL}/{userName}/{password}");
                    if (response.IsSuccessStatusCode && response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string respData = await response.Content.ReadAsStringAsync();
                        walletBalanceResponse = JsonConvert.DeserializeObject<WalletBalanceResponse>(respData);
                    }
                   
                }

            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("userName", userName);
                keyValues.Add("URL", $"{Consts.WalletBalanceURL}/{userName}/{password}");
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("Wallet Balance Exception: " + ex.Message);
            }

            return walletBalanceResponse;

        }

        /// <summary>
        /// Get session token for wallet transactions
        /// </summary>
        /// <returns></returns>
        public async Task<GetSessionTokenResponse> GetWalletSessionToken()
        {
            GetSessionTokenResponse getSessionTokenResponse = null;
            try
            {
                using (HttpClient httpClient = CreateClient())
                {
                    var response = await httpClient.GetAsync(Consts.GetSessionTokenURL);
                    if (response.IsSuccessStatusCode && response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string respData = await response.Content.ReadAsStringAsync();
                        getSessionTokenResponse = JsonConvert.DeserializeObject<GetSessionTokenResponse>(respData);
                    }

                }

            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("sessionToken", Consts.GetSessionTokenURL);
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("Get session token Exception: " + ex.Message);
            }

            return getSessionTokenResponse;

        }

        /// <summary>
        /// Add wallet balance to the customer from merchant
        /// </summary>
        /// <param name="addWalletBalanceRequest"></param>
        /// <returns></returns>
        public async Task<RequestWalletBalanceResponse> AddWalletBalance(
            AddWalletBalanceRequest addWalletBalanceRequest, Dictionary<string, string> transactionRequest)
        {
            RequestWalletBalanceResponse requestWalletBalanceResponse = null;
            try
            {                
                using (HttpClient httpClient = new HttpClient())
                {
                    string inputData = JsonConvert.SerializeObject(addWalletBalanceRequest);
                    HttpContent httpContent = new StringContent(inputData);
                    httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    var response = await httpClient.PostAsync(Consts.AddWalletBalanceURL, httpContent);
                    string respData = await response.Content.ReadAsStringAsync();
                    if (response.IsSuccessStatusCode && response.StatusCode == System.Net.HttpStatusCode.Created)
                    {
                        requestWalletBalanceResponse = JsonConvert.DeserializeObject<RequestWalletBalanceResponse>(respData);
                        TransactionResponse transactionResponse = await PostTransaction(transactionRequest);
                        if(transactionResponse == null || !transactionResponse.status)
                        {
                            requestWalletBalanceResponse.status = false;
                            requestWalletBalanceResponse.message = transactionResponse.message;

                        }
                        else
                            requestWalletBalanceResponse.status = true;
                    }
                    else
                    {
                        requestWalletBalanceResponse = ReduceWalletError(respData);
                    }
                }

            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("Add Balance Request", addWalletBalanceRequest?.ToString());
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("Add Balance Exception: " + ex.Message);
                requestWalletBalanceResponse = ReduceWalletError(App.AssemblyResourceManager.GetString("UnexpectedError"));

            }
            return requestWalletBalanceResponse;
        }


        public async Task<RequestWalletBalanceResponse> ReduceWalletBalance(
           ReduceWalletBalanceRequest reduceWalletBalanceRequest, Dictionary<string, string> transactionRequest)
        {
            RequestWalletBalanceResponse requestWalletBalanceResponse = null;
            try
            {
                using (HttpClient httpClient = new HttpClient())
                {
                    string inputData = JsonConvert.SerializeObject(reduceWalletBalanceRequest);
                    HttpContent httpContent = new StringContent(inputData);
                    httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    var response = await httpClient.PostAsync(Consts.ReduceWalletBalanceURL, httpContent);
                    string respData = await response.Content.ReadAsStringAsync();
                    if (response.IsSuccessStatusCode && response.StatusCode == System.Net.HttpStatusCode.Created)
                    {
                        requestWalletBalanceResponse = JsonConvert.DeserializeObject<RequestWalletBalanceResponse>(respData);
                        TransactionResponse transactionResponse = await PostTransaction(transactionRequest);
                        if (transactionResponse == null || !transactionResponse.status)
                        {
                            requestWalletBalanceResponse.status = false;
                            requestWalletBalanceResponse.message = transactionResponse.message;

                        }
                        else
                            requestWalletBalanceResponse.status = true;
                    }
                    else
                    {
                        requestWalletBalanceResponse = AddWalletError(respData);
                    }
                }

            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("Reduce Balance Request", requestWalletBalanceResponse?.ToString());
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("reduce Balance Exception: " + ex.Message);
                requestWalletBalanceResponse = AddWalletError(App.AssemblyResourceManager.GetString("UnexpectedError"));
            }
            return requestWalletBalanceResponse;
        }


        /// <summary>
        /// To be called after wallet transactions
        /// </summary>
        /// <param name="transactionRequest"></param>
        /// <returns></returns>

        public async Task<TransactionResponse> PostTransaction(Dictionary<string, string> transactionRequest)
        {
            TransactionResponse transactionResponse = null; 
            try
            {
                using (HttpClient httpClient = CreateClient())
                {

                    var formContent = new FormUrlEncodedContent(transactionRequest);

                    var response = httpClient.PostAsync(Consts.TransactionURL, formContent).Result;
                    string contents = await response.Content.ReadAsStringAsync();
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        transactionResponse = JsonConvert.DeserializeObject<TransactionResponse>(contents);

                    }
                    else
                    {
                        ErrorResponse errrorResponse = JsonConvert.DeserializeObject<ErrorResponse>(contents);
                        transactionResponse = TransactError(errrorResponse.error);
                    }
                   
                }
            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("Transaction API", transactionRequest?.ToString());
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("Transaction API Exception: " + ex.Message);
                transactionResponse = TransactError(App.AssemblyResourceManager.GetString("UnexpectedError"));
            }
            return transactionResponse;
        }


        /// <summary>
        /// Fetches Transaction history
        /// </summary>
        /// <returns></returns>
        public async Task<TransactionHistoryListResponse> GetTransactionHistory(string userId, string numberOfRecords)
        {
            TransactionHistoryListResponse transactionHistoryListResponse = new TransactionHistoryListResponse(); 
            try
            {
                using (HttpClient httpClient = CreateClient())
                {
                    var response = httpClient.GetAsync(Consts.TransactionHistoryURL+ userId+"/"+ numberOfRecords).Result;
                    string contents = await response.Content.ReadAsStringAsync();
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        transactionHistoryListResponse.TransactionHistoryList = JsonConvert.
                            DeserializeObject<List<TransactionHistory>>(contents);
                            if (transactionHistoryListResponse.TransactionHistoryList.Count > 1)
                                transactionHistoryListResponse.TransactionHistoryList
                                .Where(x => x.transactiondate == "0000-00-00").ToList()
                                .Select(x => x.transactiondate = "5000-12-12").ToList(); //future date to avoid showing
                    }
                    else
                    {
                        TransactionErrorResponse errrorResponse = JsonConvert.DeserializeObject<TransactionErrorResponse>(contents);
                        transactionHistoryListResponse = TransactHistoryError(App.AssemblyResourceManager.GetString("NoTransactions"));
                    }
                   
                }
            }
            catch (Exception ex)
            {
                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                keyValues.Add("Transaction History URL API", Consts.TransactionHistoryURL + userId + "/" + numberOfRecords);
                Consts.TrackError(ex, keyValues);
                Debug.WriteLine("Transaction History API Exception: " + ex.Message);
                transactionHistoryListResponse = TransactHistoryError(App.AssemblyResourceManager.GetString("UnexpectedError"));
            }
            return transactionHistoryListResponse;
        }

        //public async Task ActiveRegisteredUser(string emailLink)
        //{
        //    try
        //    {
        //        using (HttpClient httpClient = CreateClient())
        //        {
        //            var response = httpClient.GetAsync(emailLink).Result;
        //            string contents = await response.Content.ReadAsStringAsync();
        //            if (response.StatusCode == System.Net.HttpStatusCode.OK)
        //            {
                        
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Dictionary<string, string> keyValues = new Dictionary<string, string>();
        //        keyValues.Add("Activate Register URL API", emailLink);
        //        Consts.TrackError(ex, keyValues);
        //        Debug.WriteLine("Activate Register URL API Exception: " + ex.Message);
        //    }
        //}

        /// <summary>
        /// Creates Login error message
        /// </summary>
        /// <param name="errorMessage"></param>
        /// <returns></returns>
        private LoginAPIWebResponse LoginError(string errorMessage)
        {
            return new LoginAPIWebResponse { status = false, message = errorMessage };
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="errorMessage"></param>
        /// <returns></returns>
        private RegisterAPIWebResponse RegisterError(string errorMessage)
        {
            return new RegisterAPIWebResponse { status = false, message = errorMessage };
        }

        /// 
        /// </summary>
        /// <param name="errorMessage"></param>
        /// <returns></returns>
        private RequestWalletBalanceResponse AddWalletError(string errorMessage)
        {
            return new RequestWalletBalanceResponse { status = false, message = errorMessage };
        }  
         
        /// 
        /// </summary>
        /// <param name="errorMessage"></param>
        /// <returns></returns>
        private RequestWalletBalanceResponse ReduceWalletError(string errorMessage)
        {
            return new RequestWalletBalanceResponse { status = false, message = errorMessage };
        }  
        
        /// 
        /// </summary>
        /// <param name="errorMessage"></param>
        /// <returns></returns>
        private TransactionResponse TransactError(string errorMessage)
        {
            return new TransactionResponse { status = false, message = errorMessage };
        } 
        
        /// 
        /// </summary>
        /// <param name="errorMessage"></param>
        /// <returns></returns>
        private TransactionHistoryListResponse TransactHistoryError(string errorMessage)
        {
            return new TransactionHistoryListResponse { status = false, message = errorMessage };
        }

        /// <summary>
        /// Athentication  token and API key
        /// </summary>
        /// <returns>new httpclient object</returns>
        private HttpClient CreateClient()
        {
            HttpClient httpClient = new HttpClient();
            string userName = "admin";
            string password = "1234";
            string encodedUserCredentails = Consts.Base64Encode(userName + ":" + password);

            httpClient.DefaultRequestHeaders.Add("Authorization", "Basic " + encodedUserCredentails);
            httpClient.DefaultRequestHeaders.Add("X-API-KEY", "admin@123");
            return httpClient;

        }
       
    }
}
