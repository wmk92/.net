﻿using HalalCafe.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HalalCafe.Services
{
    class NavigationService : INavigationService
    {
        private readonly object _sync = new object();
        private readonly Dictionary<string, Type> _pagesByKey = new Dictionary<string, Type>();
        private readonly Stack<NavigationPage> _navigationPageStack =
            new Stack<NavigationPage>();
        private NavigationPage CurrentNavigationPage => _navigationPageStack.Peek();

        public void Configure(string pageKey, Type pageType)
        {
            lock (_sync)
            {
                if (_pagesByKey.ContainsKey(pageKey))
                {
                    _pagesByKey[pageKey] = pageType;
                }
                else
                {
                    _pagesByKey.Add(pageKey, pageType);
                }
            }
        }

        public Page SetRootPage(string rootPageKey)
        {
            var rootPage = GetPage(rootPageKey);
            _navigationPageStack.Clear();
            var mainPage = new NavigationPage(rootPage);
            _navigationPageStack.Push(mainPage);
            return mainPage;
        }


        public string CurrentPageKey
        {
            get
            {
                lock (_sync)
                {
                    if (CurrentNavigationPage?.CurrentPage == null)
                    {
                        return null;
                    }

                    var pageType = CurrentNavigationPage.CurrentPage.GetType();

                    return _pagesByKey.ContainsValue(pageType)
                        ? _pagesByKey.First(p => p.Value == pageType).Key
                        : null;
                }
            }
        }

        public async Task GoBack()
        {
            var navigationStack = CurrentNavigationPage.Navigation;
            if (navigationStack.NavigationStack.Count > 1)
            {
                await CurrentNavigationPage.PopAsync();
                return;
            }

            if (_navigationPageStack.Count > 1)
            {
                _navigationPageStack.Pop();
                await CurrentNavigationPage.Navigation.PopModalAsync();
                return;
            }

            await CurrentNavigationPage.PopAsync();
        }

        public async Task NavigateModalAsync(string pageKey, bool animated = true)
        {
            await NavigateModalAsync(pageKey, null, animated);
        }

        public async Task NavigateModalAsync(string pageKey, object parameter, bool animated = true)
        {
            var page = GetPage(pageKey, parameter);
            NavigationPage.SetHasNavigationBar(page, false);
            var modalNavigationPage = new NavigationPage(page);
            await CurrentNavigationPage.Navigation.PushModalAsync(modalNavigationPage, animated);
            _navigationPageStack.Push(modalNavigationPage);
        }

        public async Task NavigateAsync(string pageKey, bool animated = true)
        {
            await NavigateAsync(pageKey, null, animated);
        }

        public async Task NavigateAsync(string pageKey, object parameter, bool animated = true)
        {
            var page = GetPage(pageKey, parameter);
            await CurrentNavigationPage.Navigation.PushAsync(page, animated);
        }

        private Page GetPage(string pageKey, object parameter = null)
        {

            lock (_sync)
            {
                if (!_pagesByKey.ContainsKey(pageKey))
                {
                    throw new ArgumentException(
                        $"No such page: {pageKey}. Did you forget to call NavigationService.Configure?");
                }

                var type = _pagesByKey[pageKey];
                ConstructorInfo constructor;
                object[] parameters;

                if (parameter == null)
                {
                    constructor = type.GetTypeInfo()
                        .DeclaredConstructors
                        .FirstOrDefault(c => !c.GetParameters().Any());

                    parameters = new object[]
                    {
                    };
                }
                else
                {
                    constructor = type.GetTypeInfo()
                        .DeclaredConstructors
                        .FirstOrDefault(
                            c =>
                            {
                                var p = c.GetParameters();
                                return p.Length == 1
                                       && p[0].ParameterType == parameter.GetType();
                            });

                    parameters = new[]
                    {
                        parameter
                    };
                }

                if (constructor == null)
                {
                    throw new InvalidOperationException(
                        "No suitable constructor found for page " + pageKey);
                }

                var page = constructor.Invoke(parameters) as Page;
                return page;
            }
        }

        public async Task SetCurrentRootPage(string toPage,object parameter, Boolean anim)
        {
            
            await NavigateAsync(toPage, parameter, anim);
            var navigationStack = CurrentNavigationPage.Navigation;
            var count = navigationStack.NavigationStack.Count - 1;
            for (int page = 0; page < count; page++)
            {
                navigationStack.RemovePage(navigationStack.NavigationStack[0]);
            }
        }

        public async Task SetCurrentRootPage(string toPage, Boolean anim)
        {
            await NavigateAsync(toPage, anim);
            var navigationStack = CurrentNavigationPage.Navigation;
            var count = navigationStack.NavigationStack.Count - 1;
            for (int page = 0; page < count; page++)
            {
                navigationStack.RemovePage(navigationStack.NavigationStack[0]);
            }
        }
        

        public void InsertPageBefore(string pageKey)
        {
            var page = GetPage(pageKey, null);
            var pgBefore = GetPage(CurrentPageKey, null);

            CurrentNavigationPage.Navigation.InsertPageBefore(page, pgBefore);
        }

        public async void GoNextRemovePrevious(string toPage, Boolean anim)
        {
            await NavigateAsync(toPage, anim);
            var navigationStack = CurrentNavigationPage.Navigation;
            navigationStack.RemovePage(navigationStack.NavigationStack[navigationStack.NavigationStack.Count - 2]);
        }

        public void RemovePreviousPages(int noOfPages)
        {
            var navigationStack = CurrentNavigationPage.Navigation;
            int i = 0;
            int page = navigationStack.NavigationStack.Count;
            while (i < noOfPages)
            {
                if (noOfPages == 2 && i == 0)
                {
                    navigationStack.RemovePage(navigationStack.NavigationStack[page - 2]);
                }
                else
                {
                    navigationStack.RemovePage(navigationStack.NavigationStack[page - 1]);
                }
                page--;
                i++;
            }
        }

        public NavigationPage SetNavigationHeaderTheme(Page page)
        {
            var mainPage = new NavigationPage(page);
            return mainPage;
        }


    }
}
