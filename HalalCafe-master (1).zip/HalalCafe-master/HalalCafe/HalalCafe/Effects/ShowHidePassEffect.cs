﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace HalalCafe.Effects
{
    /// <summary>
    /// Eye icon placing on the Entry and it's action
    /// </summary>
    class ShowHidePassEffect : RoutingEffect
    {
        public string EntryText { get; set; }
        public ShowHidePassEffect() : base("Xamarin.ShowHidePassEffect") { }
    }
}
