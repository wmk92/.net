using HalalCafe.Common;
using HalalCafe.Interfaces;
using HalalCafe.Services;
using HalalCafe.ViewModels;
using HalalCafe.Views;
using MvvmHelpers;
using Plugin.Connectivity;
using Plugin.Connectivity.Abstractions;
using System;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Microsoft.AppCenter;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using Com.OneSignal;

[assembly: XamlCompilation (XamlCompilationOptions.Compile)]
namespace HalalCafe
{
	public partial class App : Application
	{
        #region  Properties
        public static INavigationService NavigationService { get; } = new NavigationService();

        private static ResourceManager _assemblyResourceManager;
        public static ResourceManager AssemblyResourceManager
        {
            get
            {
                if (_assemblyResourceManager == null)
                {
                    string ResourceFile = "HalalCafe.Properties.Resources";
                    _assemblyResourceManager = new ResourceManager(ResourceFile, typeof(App).Assembly);
                }
                return _assemblyResourceManager;
            }
        }
        #endregion
        #region Methods

        /// <summary>
        /// Initializes xamarin xaml files
        /// Register all the pages here for Navigation 
        /// </summary>
        public App ()
		{
			InitializeComponent();
            CrossConnectivity.Current.ConnectivityChanged -= CheckConnectionState;
            CrossConnectivity.Current.ConnectivityChanged += CheckConnectionState;
            //OneSignal.Current.StartInit("83369d63-bcee-44b7-ad7b-06e7bde92bca")                 
            //      .EndInit(); //TODO

            try
            {                
                NavigationService.Configure("TermsAndConditionsPage", typeof(TermsAndConditionsPage));
                NavigationService.Configure("MainMasterDetailPage", typeof(MainMasterDetailPage));
                NavigationService.Configure("LoginPage", typeof(LoginPage));
                NavigationService.Configure("CustomerHomePage", typeof(CustomerHomePage));
                NavigationService.Configure("MerchantHomePage", typeof(MerchantHomePage));
                NavigationService.Configure("HistoryPage", typeof(HistoryPage));
                NavigationService.Configure("BarcodeScannerPage", typeof(BarcodeScannerPage));
                NavigationService.Configure("PaymentPage", typeof(PaymentPage));
                NavigationService.Configure("TransactionDetailsPage", typeof(TransactionDetailsPage));
                NavigationService.Configure("SignUp", typeof(SignUp));
                NavigationService.Configure("CustomerQRPage", typeof(CustomerQRPage));
                NavigationService.Configure("DateFilter", typeof(DateFilter));

                if (Settings.IsTermsAccepted)
                     MainPage = ((NavigationService)NavigationService).SetRootPage("LoginPage"); // After Terms accepted
                else
                     MainPage = ((NavigationService)NavigationService).SetRootPage("TermsAndConditionsPage"); // Root page

            }
            catch (Exception e)
            {              
                Debug.WriteLine("StartPage() Exception: " + e.Message);
            }
        }

       

        /// <summary>
        /// Default to English irrespective user language
        /// </summary>
        private void SetCultureToUSEnglish()
        {
            CultureInfo englishUSCulture = new CultureInfo("en-US");
            CultureInfo.DefaultThreadCurrentCulture = englishUSCulture;
            CultureInfo.DefaultThreadCurrentUICulture = englishUSCulture;
            Console.WriteLine("CurrentCulture is now {0}.", CultureInfo.CurrentCulture.Name);

        }

        //When internet status changes
        private void CheckConnectionState(object sender, Plugin.Connectivity.Abstractions.ConnectivityChangedEventArgs args)
        {
            try
            {
                    AppBaseViewModel currentPage;
                    var mainPage = ((Application.Current.MainPage as NavigationPage).CurrentPage as Xamarin.Forms.MasterDetailPage);
                    if (mainPage != null)
                        currentPage = ((mainPage.Detail as NavigationPage).CurrentPage.BindingContext as AppBaseViewModel);

                    else
                        currentPage = ((Application.Current.MainPage as NavigationPage).CurrentPage.BindingContext as AppBaseViewModel);

                    currentPage.StopLoading();
                    Consts.InternetAvailability = args.IsConnected;
                    currentPage.ShowInternetStatus = args.IsConnected; //internet status

            }
            catch (Exception ex)
            {
                Debug.WriteLine("Connection status change" + ex.Message);
            }
        }
        protected override void OnStart ()
		{
            // Handle when your app starts
          //  #if !DEBUG
                AppCenter.Start("android=c3cb587d-708b-47a4-96f8-76c56f39f090;", typeof(Analytics), typeof(Crashes));
         //   #endif    
        }

        protected override void OnSleep ()
		{
			// Handle when your app sleeps
		}

		protected override void OnResume ()
		{
			// Handle when your app resumes
		}

#endregion
    }
}
