﻿using System;

using Android.App;
using Android.Content.PM;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Lottie.Forms.Droid;
using Android.Support.V4.Content;
using Android;
using System.Collections.Generic;
using Plugin.CurrentActivity;
using Android.Webkit;

namespace HalalCafe.Droid
{             
    [Activity(Label = "GoHalal", Icon = "@mipmap/icon", Theme = "@style/Splashscreen",
        MainLauncher = true, ScreenOrientation = ScreenOrientation.Portrait, 
        ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class MainActivity : global::Xamarin.Forms.Platform.Android.FormsAppCompatActivity
    {
        protected override void OnCreate(Bundle bundle)
        {
            TabLayoutResource = Resource.Layout.Tabbar;
            ToolbarResource = Resource.Layout.Toolbar;
            base.SetTheme(Resource.Style.MainTheme);
            base.OnCreate(bundle);
            CrossCurrentActivity.Current.Init(this, bundle);
            global::Xamarin.Forms.Forms.Init(this, bundle);
            AnimationViewRenderer.Init();
            global::ZXing.Net.Mobile.Forms.Android.Platform.Init();           
            LoadApplication(new App());
            Window.SetSoftInputMode(Android.Views.SoftInput.AdjustResize);            
        }

        /// <summary>
        /// Zxing permission
        /// </summary>
        /// <param name="requestCode"></param>
        /// <param name="permissions"></param>
        /// <param name="grantResults"></param>
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            try
            {
                if (ContextCompat.CheckSelfPermission(this, Manifest.Permission.Camera)
                    == (int)Permission.Granted)// We have permission
                {
                    global::ZXing.Net.Mobile.Android.PermissionsHandler.OnRequestPermissionsResult(requestCode, permissions, grantResults);
                }
            }
            catch (Exception ex)
            {
               // Dictionary<string, string> keyValues = new Dictionary<string, string>();
              //  keyValues.Add("RequestCode: ", requestCode.ToString(CultureInfo.InvariantCulture));
              //  Consts.TrackError(ex, keyValues);
                System.Diagnostics.Debug.WriteLine("Permission Exception: " + ex.Message);
            }
        }

        //public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Android.Content.PM.Permission[] grantResults)
        //{
        //    Plugin.Permissions.PermissionsImplementation.Current.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        //}
    }
}

